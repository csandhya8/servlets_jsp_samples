package net.codejava.upload;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.io.IOUtils;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSInputFile;

//import controller.MetaData;

public class ToMongo {

	 public static byte[] LoadImage(String filePath) throws Exception {
	        //File file = new File(filePath);
	        int size = (int)( filePath).length();
	        byte[] buffer = new byte[size];
	        FileInputStream in = new FileInputStream( filePath);
	        in.read(buffer);
	        in.close();
	        return buffer;
	    }

	    public static byte[] main(File image,MongoBean tb) throws Exception {
	        //Load our image
	      byte[] imageBytes = LoadImage(image.getAbsolutePath());
	        //Connect to database
	    	
	        MongoClient client = new MongoClient("localhost",27017);
			String connectPoint = client.getConnectPoint();
			
			System.out.println("The connected host is \t"+connectPoint);
			DB db = client.getDB("myimage");
			//DBCollection collection = db.getCollection("raise");
	        //Create GridFS object
	        GridFS fs = new GridFS( db );
	        //Save image into database
	        GridFSInputFile in = fs.createFile(imageBytes);
	        System.out.println("Image created");
	        in.setFilename("hjguyt");
	        in.save();
	        System.out.println("The pic is uploaded in the database");
	        
	        //to set metadata
	       /* DBCollection collection = db.getCollection("fs.files");
			
			System.out.println("documents inserted..");
			
			
			BasicDBObject document = new BasicDBObject();
			
         
			document.append("img_ID",tb.getImage_ID());
			document.append("contentType",tb.getContentType());
			
			collection.insert(document);
*/
	        //Find saved image
	        GridFSDBFile out = fs.findOne(new BasicDBObject().append("filename", in.getFilename()));
	        
	        System.out.println("\n Image Id:\t"+in.getId().toString());
	        System.out.println("\n retrieved from database successfully");
            System.out.println("\n GridFSDBFile value "+ out);
           
            File retrievedFile = new File("D:image retrieval");
            byte[] img = getFile(out);
	        //Save loaded image from database into new image file
	      // FileOutputStream outputImage = new FileOutputStream("D:/Backup/uploads/visitor.jpg");
	       out.writeTo(retrievedFile);
	       System.out.println("out.write successful");

	       return img;
	       //outputImage.close();
	    }
	    
	    private static byte[] getFile(GridFSDBFile queryFile){
	    	byte[] file = null;
	    	if(queryFile != null){
	    		ByteArrayOutputStream bao = null;
	    		try {
	    			bao = new ByteArrayOutputStream();
	    			queryFile.writeTo(bao);
	    			file = bao.toByteArray();
	    		} catch (IOException e) {
	    			
	    		} finally{
	    			IOUtils.closeQuietly(bao);
	    		}
	    	}
	    	return file;
	    }

		
}
