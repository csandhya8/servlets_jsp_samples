package net.codejava.upload;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
//import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;


//import net.codejava.upload.TestConnection;



/**
 * A Java servlet that handles file upload from client.
 * @author www.codejava.net
 */
public class UploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final String UPLOAD_DIRECTORY = "upload";
	private static final int THRESHOLD_SIZE 	= 1024 * 1024 * 3; 	// 3MB
	private static final int MAX_FILE_SIZE 		= 1024 * 1024 * 40; // 40MB
	private static final int MAX_REQUEST_SIZE 	= 1024 * 1024 * 50; // 50MB

	/**
	 * handles file upload via HTTP POST method
	 */
	public void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// checks if the request actually contains upload file
		RequestDispatcher rd = null;

		String module = request.getParameter("module");
		System.out.println("module value " + module);
		
		if (ServletFileUpload.isMultipartContent(request)) {
			List ImageList = new ArrayList();
			System.out.println("Enetered file part if block");
			int i=0;
			DiskFileItemFactory factory = new DiskFileItemFactory();
			factory.setSizeThreshold(THRESHOLD_SIZE);
			factory.setRepository(new File(System.getProperty("java.io.tmpdir")));
			
			ServletFileUpload upload = new ServletFileUpload(factory);
			upload.setFileSizeMax(MAX_FILE_SIZE);
			upload.setSizeMax(MAX_REQUEST_SIZE);
			
			// constructs the directory path to store upload file
			String uploadPath = getServletContext().getRealPath("")
				+ File.separator + UPLOAD_DIRECTORY;
			System.out.println("UploadPath value " + uploadPath);
			// creates the directory if it does not exist
			File uploadDir = new File(uploadPath);
			if (!uploadDir.exists()) {
				uploadDir.mkdir();
			}
			
			try {
				// parses the request's content to extract file data
				List formItems = upload.parseRequest(request);
				Iterator iter = formItems.iterator();
				String[] text = new String[35];
				String filePath = null;
				// iterates over form's fields
				while (iter.hasNext()) {
					FileItem item = (FileItem) iter.next();
					// processes only fields that are not form fields
					if (!item.isFormField()) {
						String fileName = new File(item.getName()).getName();
						filePath = uploadPath + File.separator + fileName;
						File storeFile = new File(filePath);
						
						// saves the file on disk
						item.write(storeFile);
						
						MongoBean md = new MongoBean(); 
						String img_ID = "bs00483085_1";
						String content = "jpg";
						
						
						System.out.println("\n the uploading file's path:\t"+filePath );
						md.setImage_ID(img_ID);
						md.setContentType(content);
						
						byte[] img = ToMongo.main(storeFile , md);
						String imageString = javax.xml.bind.DatatypeConverter.printBase64Binary(img);
						//System.out.println("ImageString " + imageString);
						
						ImageList.add(imageString);
						//HttpSession hs = request.getSession();
						System.out.println("imageList size"+ ImageList.size());
						HttpSession hs = request.getSession();
						request.setAttribute("image", ImageList);
					    
					
					}else{
						
					    text[i] = item.getString();
						//System.out.println("\nField Name "+);
						System.out.println("Text input " +i+" "+ text[i]);
						i++;
					}
							//new File(filePath).delete();				
				}
				
				  
			   request.setAttribute("message", "Data Updated Successfully");

				new File(filePath).delete();
			} catch (Exception ex) {
			   request.setAttribute("message", "There was an error: " + ex.getMessage());
			}
			getServletContext().getRequestDispatcher("/message.jsp").forward(request, response);
					}
		
		else if(module.equals("login")){
			HttpSession hs = request.getSession(true);
			
	        String uname = request.getParameter("user");
	        String pswd = request.getParameter("pass");
	        System.out.println("\n"+uname);
	        System.out.println("\n"+pswd);
	        hs.setAttribute("uname",uname);
	        String userNo = (String) hs.getAttribute("uname");
	        String f_key = userNo.substring(4);
	        hs.setAttribute("f_key",f_key);
	       
	        TestConnection tc =  new TestConnection();
	        if(tc.validate(uname, pswd)){
	        	//System.out.println("\n entered if class...");
	        	String[] detail = new String[2];
	        	detail = tc.getDetails(uname, pswd);
	        	System.out.println("UNAME:\t"+detail[0]);
	        	System.out.println("ibu:\t"+detail[1]);
	            System.out.println("Login Successfull...\n");
	            hs.setAttribute("user", detail[0]);
	            String user = (String) hs.getAttribute("user");
	            hs.setAttribute("ibu", detail[1]);
	            String ibu = (String) hs.getAttribute("ibu");
	            rd = request.getRequestDispatcher("Upload.jsp");
	            
	            rd.forward(request,response);
	                   }
	        else{
	            System.out.println("Couldn't login\n");
	            request.setAttribute("EmptyText","Invalid Username or Password");    
	            rd = request.getRequestDispatcher("login.jsp");
	            rd.forward(request,response);
	            System.out.println("rd value:\t"+rd);
		}
		}
		}
	
	 public static String imageToBase64String(File imageFile)throws Exception{
		    System.out.println("image to string block 1");
		    String image=null;
		    BufferedImage buffImage = ImageIO.read(imageFile);
		    System.out.println("imageToBase64String block");
		 if (buffImage != null) {
		    java.io.ByteArrayOutputStream os = new java.io.ByteArrayOutputStream();
		    ImageIO.write(buffImage, "jpg", os);
		    byte[] data = os.toByteArray();
//		    image = MyBase64.encode(data);

		//write to file the encoded character
		os.close();
		image = javax.xml.bind.DatatypeConverter.printBase64Binary(data);
		      }//if
		    return image;
		   }
}