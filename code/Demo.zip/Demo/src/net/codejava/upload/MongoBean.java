package net.codejava.upload;

public class MongoBean {

	private String image_ID;
	private String contentType;
	
	public MongoBean (String image_ID, String contentType) {
		super();
		this.image_ID = image_ID;
		this.contentType = contentType;
	}
	
	public MongoBean(){
		
	}

	public String getImage_ID() {
		return image_ID;
	}

	public void setImage_ID(String image_ID) {
		this.image_ID = image_ID;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	
}
