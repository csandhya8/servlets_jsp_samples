package com.tp.connection;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;



import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;

import com.mongodb.MongoClient;
import com.tp.bean.VisitorBean;

public class EditRequest {
	
	 public List<BasicDBObject> retrieveToView(String[] view,String userNo) throws UnknownHostException{
	    	System.out.println("Control inside View Request Class");
	    	
	    	MongoClient client = new MongoClient("localhost",27017);
			DB db = client.getDB("mydb");
			DBCollection collection = db.getCollection("raise");
			System.out.println("Status value:\t" + view[0] + "\nVisitor Type:\t" + view[1]);
			
			BasicDBObject criteria = new BasicDBObject();
			List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
			
	    System.out.println("\n associate ID:\t"+view[5]);
			
	    for(int i=0; i<=5; i++){
				System.out.println("for block value: "+view[i]);
				if(!(view[i]=="" || view[i]==null )){
					System.out.println("Entering if block with value "+view[i]);
					switch(i){
					case 0:
						criteria.append("visitor_Type", view[0]);
						System.out.println("case 0 executed");
						break;
					case 1:
						criteria.append("status",view[1]);
						System.out.println("case 1 executed");
						break;
					case 2:
						criteria.append("start_Date", new BasicDBObject("$gte", view[2]));
						System.out.println("case 2 executed");
						break;
					case 3:
						criteria.append("End_Date", new BasicDBObject("$lte", view[3]));
						System.out.println("case 3 executed");
						break;
					case 4:
						criteria.append("associate_Mob", view[4]);
						System.out.println("case 4 executed");
					case 5:
						criteria.append("associate_ID", view[5]);
						System.out.println("case 5 executed");	
					}
				}
			}
			
			if(criteria.isEmpty()){
				
	            System.out.println("criteria empty");
	            DBCursor cur = collection.find(criteria);
	            while(cur.hasNext()){
	            	
	                viewList.add((BasicDBObject) cur.next());
	        }
	        }else{
			

			DBCursor li = collection.find(criteria);
			while(li.hasNext()){
			    viewList.add((BasicDBObject) li.next());     
			}
	        }
			System.out.println(criteria.toString());
			return viewList;
	    }

public void visitorAdd_E(VisitorBean vb,String f_ID){
                    
                     MongoClient client = new MongoClient("localhost",27017);
                     String connectPoint = client.getConnectPoint();
                    
                     System.out.println("The connected host is \t"+connectPoint);
                     DB db = client.getDB("mydb");
                     DBCollection collection = db.getCollection("VisitorDetails");
                    
                     System.out.println("insertion is gonna be started............");
                    
                     BasicDBObject document = new BasicDBObject();
                   
                    document.append("visitor_Name",vb.getVisitor_Name());
             		document.append("company_Name",vb.getCompany_Name());
             		document.append("email_ID",vb.getEmail_ID());
             		document.append("visitor_Mob",vb.getVisitor_Mob());
             		document.append("country",vb.getCountry());
             		document.append("visitor_City",vb.getVisitor_City());
             		document.append("visitor_Adr",vb.getVisitor_Adr());
             		document.append("visitor_ID_Prf",vb.getVisitor_ID_Prf());
             		document.append("visitor_Prf_Num",vb.getVisitor_Prf_Num());
             		document.append("visitor_Nationality",vb.getVisitor_Nationality());
             		document.append("foreign",vb.getForeign());
             		document.append("visitor_Num",vb.getVisitor_Num());
             		document.append("r_status","not visited");
             		document.append("gadgets", vb.getGadgets());
             		document.append("s_Num",vb.getS_Num());
             		document.append("m_Name",vb.getM_Name());

                    
                     collection.insert(document);
                    
                     System.out.println("the document is inserted......");
             
 
                     System.out.println("Successfully inserted");
                    
              client.close();
                    
              }

}
