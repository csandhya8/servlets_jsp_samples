package com.tp.connection;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.*;
import org.bson.types.ObjectId;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSInputFile;
import com.tp.bean.TestBean;
import com.tp.bean.VisitorBean;
import com.tp.bean.TestBean;



public class TestConnection {
	
	public String retrieve_ID() throws UnknownHostException{
		
		MongoClient client = new MongoClient("localhost",27017);
		String connectPoint = client.getConnectPoint();
		
		System.out.println("The connected host is \t"+connectPoint);
		DB db = client.getDB("mydb");
		DBCollection collection = db.getCollection("raise");
		DBObject query = new BasicDBObject();
		
		DBCursor cursor = collection.find(query).sort(new BasicDBObject("$natural", -1)).limit(1);
		String _id = null;
		for (DBObject dbObject : cursor){ 
	        System.out.println(dbObject);
		
		_id = (String) dbObject.get("foreign_Key").toString();
	
		
		System.out.println("the retrieved id:\t"+_id);
	
		}
		
		return _id;
}
		
	
 public String DBinsert(TestBean tb,String gid) throws Exception{
		MongoClient client = new MongoClient("localhost",27017);
		String connectPoint = client.getConnectPoint();
		
		System.out.println("The connected host is \t"+connectPoint);
		DB db = client.getDB("mydb");
		DBCollection collection = db.getCollection("raise");
		
		System.out.println("documents inserted..");
		
		
		BasicDBObject document = new BasicDBObject();
		

		document.append("associate_ID",tb.getAssociate_ID());
		document.append("associate_Name",tb.getAssociate_Name());
		document.append("associate_Mob",tb.getAssociate_Mob());
		document.append("visitor_Type",tb.getVisitor_Type());
		document.append("escorted_By",tb.getEscorted_By());	
		document.append("host_City",tb.getHost_City());
		document.append("Associate_Loc",tb.getAssociate_Loc());
		document.append("start_Date",tb.getStart_Date());
		document.append("End_Date",tb.getEnd_Date());
		document.append("foreign_Key",tb.getForeign_Key());
		document.append("request_Raised_at",tb.getRequest_Raised_at());
		document.append("no_Of_Visitors", tb.getNo_Of_Visitors());
		document.append("status", "submitted");
		document.append("r_Status", "not_visited");
		
		collection.insert(document);
		
		 String f_ID = document.get("foreign_Key").toString();
		 
		 System.out.println("f_key:\t"+f_ID);
		 
		 DBObject query = new BasicDBObject("foreign_Key",f_ID);
		 DBObject view = new BasicDBObject();
		 view = collection.findOne(query);
			System.out.println("the document contains \t"+view);
		
		System.out.println("Successfully inserted");
		
		
		
		client.close();
		
		return f_ID;
	}
	
public void visitorAdd(VisitorBean vb,String f_ID) throws UnknownHostException{
		
		MongoClient client = new MongoClient("localhost",27017);
		String connectPoint = client.getConnectPoint();
		
		System.out.println("The connected host is \t"+connectPoint);
		DB db = client.getDB("mydb");
		DBCollection collection = db.getCollection("VisitorDetails");
		
		System.out.println("insertion is gonna be started............");
		
		BasicDBObject document = new BasicDBObject();
		document.append("visitor_Name",vb.getVisitor_Name());
		document.append("company_Name",vb.getCompany_Name());
		document.append("email_ID",vb.getEmail_ID());
		document.append("visitor_Mob",vb.getVisitor_Mob());
		document.append("country",vb.getCountry());
		document.append("visitor_City",vb.getVisitor_City());
		document.append("visitor_Adr",vb.getVisitor_Adr());
		document.append("visitor_ID_Prf",vb.getVisitor_ID_Prf());
		document.append("visitor_Prf_Num",vb.getVisitor_Prf_Num());
		document.append("visitor_Nationality",vb.getVisitor_Nationality());
		document.append("foreign",vb.getForeign());
		document.append("visitor_Num",vb.getVisitor_Num());
		//document.append("r_status","not visited");
		
		collection.insert(document);
		
		System.out.println("the document is inserted......");
		String id = document.get("_id").toString();
		String id_1 = document.get("foreign").toString();
		String num_1 = document.get("visitor_Num").toString();
		System.out.println("\n the visitor number is:\t"+num_1);
		 System.out.println(id);
		 DBObject query = new BasicDBObject("foreign",id_1);
		 DBObject view = new BasicDBObject();
		 view = collection.findOne(query);
		System.out.println("the document contains \t"+view);
		
		System.out.println("Successfully inserted");
		
		
		DBCursor cursor = collection.find(query).sort(new BasicDBObject("$natural", -1)).limit(1);

		
	client.close();
		
	}
	
public List<BasicDBObject> retrieveList(int range,String r_ID) throws UnknownHostException{
		 MongoClient client = new MongoClient("localhost",27017);
		 
			String connectPoint = client.getConnectPoint();
			
			System.out.println("The connected host is \t"+connectPoint);
			DB db = client.getDB("mydb");
			DBCollection collection = db.getCollection("VisitorDetails");
			
			System.out.println("\n retrieve list query executing.............");
			
			List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
			
			DBObject query = new BasicDBObject("foreign",r_ID);
			
			DBCursor li = collection.find(query).sort(new BasicDBObject("$natural", -1)).limit(range);
			while(li.hasNext()){
			    viewList.add((BasicDBObject) li.next());     
			}
			
			client.close();
			return viewList;
	 }
	
public boolean validate(String u_name, String pswd,String login) throws UnknownHostException{
	    	MongoClient client = new MongoClient("localhost",27017);
			String connectPoint = client.getConnectPoint();
			System.out.println("The connected host is \t"+connectPoint);
			DB db = client.getDB("mydb");
			System.out.println("\n"+u_name);
			System.out.println("\n"+pswd);
			DBCollection collection = db.getCollection(login);
			List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
			BasicDBObject document = new BasicDBObject();
			DBCursor cursor = collection.find();
		    
			boolean b=false;
			DBObject dbo;
			while(cursor.hasNext()){
				System.err.println("\n entered while........");
				
				dbo = cursor.next();
				String una = (String)dbo.get("gid");
				String pwd = (String)dbo.get("pswd");
				
				if( u_name.compareToIgnoreCase(una)==0 && pswd.compareToIgnoreCase(pwd)==0) {
					 b = true;
					 System.out.println("\n the boolean is:\t"+b);
				}
			}
			client.close();
			return b;
	    }
	
public String[] getDetails(String u_name, String pswd,String login) throws UnknownHostException{
    	MongoClient client = new MongoClient("localhost",27017);
		String connectPoint = client.getConnectPoint();
		System.out.println("The connected host is \t"+connectPoint);
		String[] detail = new String[3];
		DB db = client.getDB("mydb");
		System.out.println("\n"+u_name);
		System.out.println("\n"+pswd);
		DBCollection collection = db.getCollection(login);
		List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
		
		DBCursor cursor = collection.find();
		boolean b=false;
		DBObject dbo;
		while(cursor.hasNext()){
			dbo = cursor.next();
			String una = (String)dbo.get("gid");
			String pwd = (String)dbo.get("pswd");
				if( u_name.compareToIgnoreCase(una)==0 && pswd.compareToIgnoreCase(pwd)==0) {
				 detail[0]  =(String) dbo.get("uname");
				 detail[1]  = (String)dbo.get("IBU");
				 if(login.equals("Security")){
			         detail[2] = (String)dbo.get("location");
			     }  
		}
		}
		
		client.close();
		return detail;
    }
	 
public void DBupdate(VisitorBean vb ,String visitor,String r_ID,int range) throws UnknownHostException{
		 MongoClient client = new MongoClient("localhost",27017);
			String connectPoint = client.getConnectPoint();
			System.out.println("The connected host is \t"+connectPoint);
			DB db = client.getDB("mydb");
			
			DBCollection collection = db.getCollection("VisitorDetails");
			
			System.out.println("\n the id of the document to be updated is:\t"+visitor);
			
			BasicDBObject andQuery = new BasicDBObject();
			List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
			obj.add(new BasicDBObject("visitor_Num", visitor));
			obj.add(new BasicDBObject("foreign", r_ID));
			andQuery.put("$and", obj);

			System.out.println(andQuery.toString());
			DBObject dbo = new BasicDBObject();
			DBCursor query = collection.find(andQuery).sort(new BasicDBObject("$natural", -1)).limit(range);
			while(query.hasNext()){
				dbo = query.next();
				}
			
			
			BasicDBObject updateFields = new BasicDBObject();
			updateFields.append("gadgets", vb.getGadgets());
			updateFields.append("s_Num",vb.getS_Num());
			updateFields.append("m_Name",vb.getM_Name());
			BasicDBObject setQuery = new BasicDBObject();
			setQuery.append("$set", updateFields);
			collection.update(dbo, setQuery);
			
			System.out.println("\n the document for and query is:\t"+updateFields);
			
			WriteResult result = collection.update(dbo, setQuery);
			
			System.out.println("write result value:\t"+result);
			
			
			
			
                        client.close();
	 }
	 
public List<BasicDBObject> recordRetrieve(String value) throws UnknownHostException{
		 
		 MongoClient client = new MongoClient("localhost",27017);
			String connectPoint = client.getConnectPoint();
			System.out.println("The connected host is \t"+connectPoint);
			DB db = client.getDB("mydb");
			
			DBCollection collection = db.getCollection("raise");
			
			
			
			
List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
			
			DBObject query = new BasicDBObject("foreign_Key",value);
			
			DBCursor li = collection.find(query);
			while(li.hasNext()){
			    viewList.add((BasicDBObject) li.next());     
			}
			
			System.out.println("\n the value of size of Record retrieve  is:\t"+viewList.size());
		    return viewList;
	
		
		
	 }
public List<BasicDBObject> recordRetrieve_1(String value) throws UnknownHostException{
		 
		 MongoClient client = new MongoClient("localhost",27017);
			String connectPoint = client.getConnectPoint();
			System.out.println("The connected host is \t"+connectPoint);
			DB db = client.getDB("mydb");
			
			
			DBCollection collection_1 = db.getCollection("VisitorDetails");
			
			
			
List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
			
			
			DBObject query_1 = new BasicDBObject("foreign",value);
			
			DBCursor li_1 = collection_1.find(query_1);
			while(li_1.hasNext()){
			    viewList.add((BasicDBObject) li_1.next());     
			}
		    client.close();
		    System.out.println("\n the value of size of record retrieve_1 is:\t"+viewList.size());
		    		    return viewList;
	
		
		
	 }
public List<BasicDBObject> edit(String value) throws UnknownHostException{
	 
	 MongoClient client = new MongoClient("localhost",27017);
		String connectPoint = client.getConnectPoint();
		System.out.println("The connected host is \t"+connectPoint);
		DB db = client.getDB("mydb");
		
		DBCollection collection = db.getCollection("raise");
		
		
		
		
List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
		
		DBObject query = new BasicDBObject("foreign_Key",value);
		
		DBCursor li = collection.find(query);
		while(li.hasNext()){
		    viewList.add((BasicDBObject) li.next());     
		}
		
		System.out.println("\n the value of size is:\t"+viewList.size());
	    return viewList;

}

public static byte[] LoadImage(File filePath) throws Exception {
    //File file = new File(filePath);
    int size = (int)( filePath).length();
    byte[] buffer = new byte[size];
    FileInputStream in = new FileInputStream( filePath);
    in.read(buffer);
    in.close();
    return buffer;
}

public void InsertImage(File image, String fileName) throws Exception {
    //Load our image
   byte[] imageBytes = LoadImage(image);
   
	//Connect to database
	
    MongoClient client = new MongoClient("localhost",27017);
	String connectPoint = client.getConnectPoint();
	
	DB db = client.getDB("myimage");
	//DBCollection collection = db.getCollection("raise");
    //Create GridFS object
    GridFS fs = new GridFS( db );
    //Save image into database
    GridFSInputFile fileIn = fs.createFile(imageBytes);
    fileIn.setFilename(fileName);
    fileIn.save();
    System.out.println("The pic is uploaded in the database");
}

	 }
