package com.tp.connection;

import java.util.ArrayList;
import java.util.List;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

public class QRGenerator {
	
	public  List<BasicDBObject> QRRecord(String qrCode,String v_Num){
		
		System.out.println("\n entered qrgen");

        MongoClient client = new MongoClient("localhost",27017);
    DB db = client.getDB("mydb");
    DBCollection collection = db.getCollection("VisitorDetails");
    DBCollection col = db.getCollection("raise");
   
    List<BasicDBObject> qrList = new ArrayList<BasicDBObject>();
    DBObject query = new BasicDBObject("foreign_Key",qrCode);
    DBCursor li = col.find(query);   
    BasicDBObject raise = (BasicDBObject)li.next();
   
    BasicDBObject qrCriteria = new BasicDBObject();
    qrCriteria.append("foreign", qrCode);
    System.out.println("\n the details og qr_gen:\t"+qrCode+v_Num);
    qrCriteria.append("visitor_Num", v_Num);
    DBCursor obj = collection.find(qrCriteria);
    
    BasicDBObject v_Detail = (BasicDBObject)obj.next();
       
	   qrList.add((BasicDBObject) raise);
       qrList.add((BasicDBObject) v_Detail);
   
		return qrList;
		
	}

}
