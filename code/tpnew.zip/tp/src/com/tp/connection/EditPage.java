package com.tp.connection;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;
import com.tp.bean.TestBean;
import com.tp.bean.VisitorBean;

public class EditPage {
	
	public void DBupdate(TestBean tb, String r_ID) throws UnknownHostException{
		 MongoClient client = new MongoClient("localhost",27017);
			String connectPoint = client.getConnectPoint();
			System.out.println("The connected host is \t"+connectPoint);
			DB db = client.getDB("mydb");
			
			DBCollection collection = db.getCollection("raise");
			
			BasicDBObject andQuery = new BasicDBObject("foreign_Key", r_ID);
			

			System.out.println(andQuery.toString());
			DBObject dbo = new BasicDBObject();
			DBCursor query = collection.find(andQuery);
			while(query.hasNext()){
				dbo = query.next();
				}
			
			
			BasicDBObject updateFields = new BasicDBObject();
			
			
			updateFields.append("associate_Mob",tb.getAssociate_Mob());
			updateFields.append("visitor_Type",tb.getVisitor_Type());
			updateFields.append("escorted_By",tb.getEscorted_By());	
			updateFields.append("host_City",tb.getHost_City());
			updateFields.append("Associate_Loc",tb.getAssociate_Loc());
			updateFields.append("start_Date",tb.getStart_Date());
			updateFields.append("End_Date",tb.getEnd_Date());
			updateFields.append("request_Raised_at",tb.getRequest_Raised_at());
			updateFields.append("no_Of_Visitors", tb.getNo_Of_Visitors());
			BasicDBObject setQuery = new BasicDBObject();
			setQuery.append("$set", updateFields);
			collection.update(dbo, setQuery);
			
			System.out.println("\n the document for and query is:\t"+updateFields);
			
			WriteResult result = collection.update(dbo, setQuery);
			
			System.out.println("write result value:\t"+result);
			
			
                       client.close();
	 }
	public List<BasicDBObject> recordRetrieve_1(String value){
		 
		 MongoClient client = new MongoClient("localhost",27017);
			String connectPoint = client.getConnectPoint();
			System.out.println("The connected host is \t"+connectPoint);
			DB db = client.getDB("mydb");
			
			
			DBCollection collection_1 = db.getCollection("VisitorDetails");
			
			
			
List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
			
			
			DBObject query_1 = new BasicDBObject("foreign",value);
			System.out.println("\nquery1 DBObject " + query_1.toString());
			DBCursor li_1 = collection_1.find(query_1);
			while(li_1.hasNext()){
				
			    viewList.add((BasicDBObject) li_1.next());     
			}
		    client.close();
		    System.out.println("\n the value of size is:\t"+viewList.size());
		    		    return viewList;
	
		
		
	 }
	public List<BasicDBObject> recordRetrieve_2(String value,String get_ID){
		 
		 MongoClient client = new MongoClient("localhost",27017);
			String connectPoint = client.getConnectPoint();
			System.out.println("The connected host is \t"+connectPoint);
			DB db = client.getDB("mydb");
			
			
			DBCollection collection_1 = db.getCollection("VisitorDetails");
			
			
			
List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
			
			
BasicDBObject andQuery = new BasicDBObject();
List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
obj.add(new BasicDBObject("visitor_Num", get_ID));

obj.add(new BasicDBObject("foreign", value));
andQuery.put("$and", obj);

System.out.println(andQuery.toString());;
			
			DBCursor li_2 = collection_1.find(andQuery);
			while(li_2.hasNext()){
			    viewList.add((BasicDBObject) li_2.next());     
			}
		    client.close();
		    for(BasicDBObject ab:viewList){
		    System.out.println("\n Record Retrieve 2 return list value:\t"+ab);
		    }
		    		    return viewList;
	
		
		
	 }
		
		public void v_Update(VisitorBean tb, String r_ID,String get_ID){
			 MongoClient client = new MongoClient("localhost",27017);
				String connectPoint = client.getConnectPoint();
				System.out.println("The connected host is \t"+connectPoint);
				DB db = client.getDB("mydb");
				
				DBCollection collection = db.getCollection("VisitorDetails");
				
				
				
				BasicDBObject andQuery = new BasicDBObject();
				List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
				
				obj.add(new BasicDBObject("visitor_Num", get_ID));
				obj.add(new BasicDBObject("foreign", r_ID));
				andQuery.put("$and", obj);
				

				System.out.println(andQuery.toString());
				DBObject dbo = new BasicDBObject();
				DBCursor query = collection.find(andQuery);
				while(query.hasNext()){
					dbo = query.next();
					}
				
				
				BasicDBObject updateFields = new BasicDBObject();
				
				
				updateFields.append("visitor_Name",tb.getVisitor_Name());
				updateFields.append("company_Name",tb.getCompany_Name());
				updateFields.append("email_ID",tb.getEmail_ID());	
				updateFields.append("visitor_Mob",tb.getVisitor_Mob());
				updateFields.append("country",tb.getCountry());
				updateFields.append("visitor_City",tb.getVisitor_City());
				updateFields.append("visitor_Adr",tb.getVisitor_Adr());
				updateFields.append("visitor_ID_Prf",tb.getVisitor_ID_Prf());
				updateFields.append("visitor_Prf_Num", tb.getVisitor_Prf_Num());
				updateFields.append("visitor_Nationality", tb.getVisitor_Nationality());
				updateFields.append("gadgets", tb.getGadgets());
				updateFields.append("s_Num",tb.getS_Num());
				updateFields.append("m_Name",tb.getM_Name());
				
				BasicDBObject setQuery = new BasicDBObject();
				setQuery.append("$set", updateFields);
				
				collection.update(dbo, setQuery);
				
				System.out.println("\n the document for and query is:\t"+updateFields);
				
				WriteResult result = collection.update(dbo, setQuery);
				
		
				
	                       client.close();
		 }
		public void Close_Request(String r_ID,String Close_ID){
			 MongoClient client = new MongoClient("localhost",27017);
				String connectPoint = client.getConnectPoint();
				System.out.println("The connected host is \t"+connectPoint);
				DB db = client.getDB("mydb");
				DBCollection collection = db.getCollection("VisitorDetails");
				
				BasicDBObject andQuery = new BasicDBObject();
				List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
				obj.add(new BasicDBObject("visitor_Num", Close_ID));
				obj.add(new BasicDBObject("foreign", r_ID));
				andQuery.put("$and", obj);
				
				DBCursor query = collection.find(andQuery);
				DBObject dbo = new BasicDBObject();
				dbo = query.next();
				
				BasicDBObject updateFields = new BasicDBObject();
				updateFields.append("r_status","Visited");
				BasicDBObject setQuery = new BasicDBObject();
				setQuery.append("$set", updateFields);
				collection.update(dbo, setQuery);
				client.close();
		}
		 
}



