package com.tp.connection;

import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

public class ViewRequest {
    public List<BasicDBObject> retrieveToView(String[] view,String userNo) throws UnknownHostException{
    	System.out.println("Control inside View Request Class");
    	
    	MongoClient client = new MongoClient("localhost",27017);
		DB db = client.getDB("mydb");
		DBCollection collection = db.getCollection("raise");
		System.out.println("Status value:\t" + view[0] + "\nVisitor Type:\t" + view[1]);
		
		BasicDBObject criteria = new BasicDBObject();
		List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
		
    System.out.println("\n associate ID:\t"+view[5]);
		
    for(int i=0; i<=5; i++){
			System.out.println("for block value: "+view[i]);
			if(!(view[i]=="" || view[i]==null )){
				System.out.println("Entering if block with value "+view[i]);
				switch(i){
				case 0:
					criteria.append("visitor_Type", view[0]);
					System.out.println("case 0 executed");
					break;
				case 1:
					criteria.append("status",view[1]);
					System.out.println("case 1 executed");
					break;
				case 2:
					criteria.append("start_Date", new BasicDBObject("$gte", view[2]));
					System.out.println("case 2 executed");
					break;
				case 3:
					criteria.append("End_Date", new BasicDBObject("$lte", view[3]));
					System.out.println("case 3 executed");
					break;
				case 4:
					criteria.append("associate_Mob", view[4]);
					System.out.println("case 4 executed");
				case 5:
					criteria.append("associate_ID", view[5]);
					System.out.println("case 5 executed");	
				}
			}
		}
		
		if(criteria.isEmpty()){
			
            System.out.println("criteria empty");
            DBCursor cur = collection.find(criteria);
            while(cur.hasNext()){
            	
                viewList.add((BasicDBObject) cur.next());
        }
        }else{
		

		DBCursor li = collection.find(criteria);
		while(li.hasNext()){
		    viewList.add((BasicDBObject) li.next());     
		}
        }
		System.out.println(criteria.toString());
		return viewList;
    }
    
        public List<BasicDBObject> retrieveExisting(String[] view) throws UnknownHostException{
        	System.out.println("Control inside View Request Class");
        	
        	MongoClient client = new MongoClient("localhost",27017);
    		DB db = client.getDB("mydb");
    		DBCollection collection = db.getCollection("VisitorDetails");
    		DBCollection col = db.getCollection("raise");
    		
    		BasicDBObject criteria = new BasicDBObject();
    		List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
    		
       
    		
        for(int i=0; i<4; i++){
    			
    			if(!(view[i]=="" || view[i]==null )){
    				switch(i){
    				case 0:
    					criteria.append("visitor_Name", Pattern.compile(view[0], Pattern.CASE_INSENSITIVE));
    					System.out.println("case 0 with name as criteria is executed");
    					break;
    				case 1:
    					criteria.append("visitor_Mob",view[1]);
    					System.out.println("case 1 executed");
    					break;
    				case 2:
    					criteria.append("visitor_Prf_Num", view[2]);
    					System.out.println("case 2 executed");
    					break;
    				case 3:
    					criteria.append("foreign", view[3]);
    					System.out.println("case 3 executed");
    					break;
    					
    				}
    			}
    		}
    		
    		DBCursor li = collection.find(criteria);    		
    		while(li.hasNext()){
    			
    			DBObject object = new BasicDBObject();
    			object = li.next();
    			String rid = (String) object.get("foreign");
    			BasicDBObject raiseCriteria = new BasicDBObject();
    			raiseCriteria.append("foreign_Key", rid);
    			raiseCriteria.append("associate_ID", view[4]);
    			DBCursor obj = col.find(raiseCriteria);
    			
    			System.out.println("Size of raise "+ obj.size());
    			if(obj.size() != 0){
    				viewList.add((BasicDBObject)obj.next());
    				
    			}    
    		}
    	
    		return viewList;
 
        }


        public List<BasicDBObject> retrieveToView_1(String[] view) throws UnknownHostException{
        	System.out.println("Control inside View_1 Request Class");
        	
        	MongoClient client = new MongoClient("localhost",27017);
    		DB db = client.getDB("mydb");
    		DBCollection collection = db.getCollection("VisitorDetails");
    		System.out.println("Status value:\t" + view[0] + "\nVisitor Type:\t" + view[1]);
    		
    		BasicDBObject criteria = new BasicDBObject();
    		BasicDBObject query = new BasicDBObject();
    		List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
    		
    		DateFormat dateFormat = new SimpleDateFormat("dd/MM/YYYY");
    		Date date = new Date();
    		String sysDate = dateFormat.format(date);
    		System.out.println("\n the format of the date is:\t"+sysDate);
    		
        System.out.println("\n associate ID:\t"+view[4]);
    		
        for(int i=0; i<=3; i++){
    			System.out.println("for block value: "+view[i]);
    			if(!(view[i]=="" || view[i]==null )){
    				System.out.println("Entering if block with value "+view[i]);
    				switch(i){
    				case 0:
    					
    					criteria.append("visitor_Name",view[0]);
    					System.out.println("case 0 executed");
    					break;
    				case 1:
    					criteria.append("visitor_Prf_Num",view[1]);
    					System.out.println("case 1 executed");
    					break;
    				case 2:
    					criteria.append("visitor_Mob", view[2]);
    					System.out.println("case 2 executed");
    					break;
    				case 3:
    					criteria.append("foreign",view[3]);
    					System.out.println("case 3 executed");
    					break;
    				
    				}
    			}
    		}
    		
    		if(criteria.isEmpty()){
    			
                System.out.println("criteria empty");
                DBCursor cur = collection.find(criteria);
                while(cur.hasNext()){
                	
                	DBObject object = new BasicDBObject();
        			object = cur.next();
        			String rid = (String) object.get("foreign");
        			BasicDBObject raiseCriteria = new BasicDBObject();
        			raiseCriteria.append("foreign_Key", rid);
        			raiseCriteria.append("End_Date", new BasicDBObject("$gte",sysDate));
        			raiseCriteria.append("host_City", view[4]);
        			raiseCriteria.append("r_Status", "not_visited");
        			
        			DBCollection col = db.getCollection("raise");
        			DBCursor obj = col.find(raiseCriteria);
        			
        			System.out.println("\n THE SECURITY VIEW CRITERIA:\t"+raiseCriteria.toString());
        			System.out.println("Size of raise "+ obj.size());
        			if(obj.size() != 0){
        		    viewList.add((BasicDBObject) obj.next());   
        			}
                  
           }
            }else{
    		
            System.out.println("Else Block Is Executed");
    		DBCursor li = collection.find(criteria);
    		while(li.hasNext()){
    		
    			DBObject object = new BasicDBObject();
    			object = li.next();
    			String rid = (String) object.get("foreign");
    			BasicDBObject raiseCriteria = new BasicDBObject();
    			raiseCriteria.append("foreign_Key", rid);
    			raiseCriteria.append("End_Date", new BasicDBObject("$gte",sysDate));
    			raiseCriteria.append("host_City", view[4]);
    			raiseCriteria.append("r_Status", "not_visited");
    			DBCollection col = db.getCollection("raise");
    			DBCursor obj = col.find(raiseCriteria);
    			System.out.println("\n THE SECURITY VIEW CRITERIA:\t"+raiseCriteria.toString());
    			System.out.println("Size of raise "+ obj.size());
    			if(obj.size() != 0){
    		    viewList.add((BasicDBObject) obj.next());   
    			}
    			
    		}
            }
    		System.out.println("size of security list:\t"+viewList.size());
    		
    		System.out.println(criteria.toString());
    		return viewList;
        }

        public List<BasicDBObject> retrieveToView_2(String[] view,String Report) throws UnknownHostException{
        	System.out.println("Control inside View_1 Request Class");
        	System.out.println("Report value:\t 1"+Report+"1");
        	
        	MongoClient client = new MongoClient("localhost",27017);
    		DB db = client.getDB("mydb");
    		DBCollection collection = db.getCollection("VisitorDetails");
    		System.out.println("Status value:\t" + view[0] + "\nVisitor Type:\t" + view[1]);
    		
    		BasicDBObject criteria = new BasicDBObject();
    		BasicDBObject query = new BasicDBObject();
    		List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
    		
        System.out.println("\n associate ID:\t"+view[4]);
    		
        for(int i=0; i<=3; i++){
    			System.out.println("for block value: "+view[i]);
    			if(!(view[i]=="" || view[i]==null )){
    				System.out.println("Entering if block with value "+view[i]);
    				switch(i){
    				case 0:
    					
    					criteria.append("visitor_Name",view[0]);
    					System.out.println("case 0 executed");
    					break;
    				case 1:
    					criteria.append("visitor_Prf_Num",view[1]);
    					System.out.println("case 1 executed");
    					break;
    				case 2:
    					criteria.append("visitor_Mob", view[2]);
    					System.out.println("case 2 executed");
    					break;
    				case 3:
    					criteria.append("foreign",view[3]);
    					System.out.println("case 3 executed");
    					break;
    				
    				}
    			}
    		}
    		
      if(Report=="" || Report==null){
        	/*if((criteria.isEmpty())&&((Report == " " || Report == null))){*/
    			
                System.out.println("criteria empty");
                DBCursor cur = collection.find(criteria);
                while(cur.hasNext()){
                	
                	DBObject object = new BasicDBObject();
        			object = cur.next();
        			String rid = (String) object.get("foreign");
        			BasicDBObject raiseCriteria = new BasicDBObject();
        			raiseCriteria.append("foreign_Key", rid);
        			raiseCriteria.append("host_City", view[4]);
        			
        			DBCollection col = db.getCollection("raise");
        			DBCursor obj = col.find(raiseCriteria);
        			
        			if(obj.size() != 0){
        		    viewList.add((BasicDBObject) obj.next());   
        			}
                  
           }
            }else{
    		
            System.out.println("Else Block Is Executed");
    		DBCursor li = collection.find(criteria);
    		while(li.hasNext()){
    		
    			DBObject object = new BasicDBObject();
    			object = li.next();
    			String rid = (String) object.get("foreign");
    			BasicDBObject raiseCriteria = new BasicDBObject();
    			raiseCriteria.append("foreign_Key", rid);
    			raiseCriteria.append("start_Date", new BasicDBObject("$lte",Report));
    			raiseCriteria.append("End_Date", new BasicDBObject("$gte",Report));
    			raiseCriteria.append("host_City", view[4]);
    			
    			DBCollection col = db.getCollection("raise");
    			DBCursor obj = col.find(raiseCriteria);
    			System.out.println("Size of raise "+ obj.size());
    			if(obj.size() != 0){
    				
    		    viewList.add((BasicDBObject) obj.next());   
    			}
    			
    		}
            }
    	    		return viewList;
        }
        
    
      /*  public List<BasicDBObject> admin_View(){
        	System.out.println("Control inside View_1 Request Class");
        	
        	MongoClient client = new MongoClient("localhost",27017);
    		DB db = client.getDB("mydb");
    		DBCollection collection = db.getCollection("VisitorDetails");
    		
    		BasicDBObject criteria = new BasicDBObject();
    		List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
    		
    	
    		DBCursor li = collection.find();
    		while(li.hasNext()){
    		
    			DBObject object = new BasicDBObject();
    			object = li.next();
     			String ridInVisitor = (String) object.get("foreign");
     			DBCollection coll = db.getCollection("raise");
     			BasicDBObject query = new BasicDBObject();
     			     			
       				query.append("foreign_Key", ridInVisitor);
       				
                    DBObject rec = coll.findOne(query);
                  
                    
                    //if(rec.get("host_City").equals(view[4])) {
          				 viewList.add((BasicDBObject) object);
         			
         			}

    		
        //}

    		//System.out.println("size of security list:\t"+viewList.size());
    		
    		
    		return viewList;
        }*/
}


