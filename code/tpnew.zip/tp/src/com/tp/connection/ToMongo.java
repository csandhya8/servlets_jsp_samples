package com.tp.connection;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.commons.fileupload.FileItem;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSInputFile;

//import controller.MetaData;

public class ToMongo {

	 public static byte[] LoadImage(File filePath) throws Exception {
	        //File file = new File(filePath);
	        int size = (int)( filePath).length();
	        byte[] buffer = new byte[size];
	        FileInputStream in = new FileInputStream( filePath);
	        in.read(buffer);
	        in.close();
	        return buffer;
	    }

	    public static File main(File image,String f_name) throws Exception {
	        //Load our image
	       byte[] imageBytes = LoadImage(image);
	       
	    	//Connect to database
	    	
	        MongoClient client = new MongoClient("localhost",27017);
			String connectPoint = client.getConnectPoint();
			
			DB db = client.getDB("myimage");
			//DBCollection collection = db.getCollection("raise");
	        //Create GridFS object
	        GridFS fs = new GridFS( db );
	        //Save image into database
	        GridFSInputFile fileIn = fs.createFile(imageBytes);
	        fileIn.setFilename(f_name);
	        fileIn.save();
	        System.out.println("The pic is uploaded in the database");
	        
	        
	        //Find saved image
	        GridFSDBFile out = fs.findOne( new BasicDBObject().append("filename",fileIn.getFilename()));
	        
	        //System.out.println("\n Image Id:\t"+ fileIn.getId().toString());
	        System.out.println("\n retrieved from database successfully");
            System.out.println("\n GridFSDBFile value "+ out);
            
            System.out.println("File path:"+connectPoint);

            File retrievedFile = new File(connectPoint);
           
	        //Save loaded image from database into new image file
	      // FileOutputStream outputImage = new FileOutputStream("D:/Backup/uploads/visitor.jpg");
	       out.writeTo(retrievedFile);
	     
	       return retrievedFile;
	       //outputImage.close();
	        
	        
	    }

		
}
