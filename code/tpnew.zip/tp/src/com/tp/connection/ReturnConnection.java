package com.tp.connection;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

public class ReturnConnection {
	
	private Date yesterday() {
	    final Calendar cal = Calendar.getInstance();
	    cal.add(Calendar.DATE, -1);
	    return cal.getTime();
	}
	

	public String getYesterdayDateString() {
	        DateFormat dateFormat = new SimpleDateFormat("dd/MM/YYYY");
	        return dateFormat.format(yesterday());
	}
	
	public void dateExceed(){
		MongoClient client = new MongoClient("172.18.34.229",27017);
		String connectPoint = client.getConnectPoint();
		
		System.out.println("The connected host is \t"+connectPoint);
		DB db = client.getDB("mydb");
		DBCollection collection = db.getCollection("raise");
		DBCollection collection_1 = db.getCollection("raise");
		
		
		DBObject query_1 = new BasicDBObject("End_Date",getYesterdayDateString());
		DBObject dbo = new BasicDBObject();
		DBCursor query = collection.find(query_1);
		while(query.hasNext()){
			dbo = query.next();
			String f_ID = (String) dbo.get("foreign_Key");
			
			DBObject query_2 = new BasicDBObject("foreign",f_ID);
			DBObject dbo_v = new BasicDBObject();
			DBCursor query_3 = collection_1.find(query_2);
			while(query_3.hasNext()){
				dbo_v = query_3.next();
  			BasicDBObject updateFields = new BasicDBObject();
			updateFields.append("r_Status","not_Visited");
			BasicDBObject setQuery = new BasicDBObject();
			setQuery.append("$set", updateFields);
			collection.update(dbo_v, setQuery);
			}
		}
		}



}
