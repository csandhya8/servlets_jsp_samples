package com.tp.bean;

public class VisitorBean {
	
	
	private String visitor_Name;
	private String company_Name;
	private String email_ID;
	private String visitor_Mob;
	private String country;
	private String visitor_City;
	private String visitor_Adr;
	private String visitor_ID_Prf;
	private String visitor_Prf_Num;
	private String visitor_Nationality;
	private String image;
	private String foreign;
	private String status;
	private String r_status;
	private String visitor_Num;
	
	private String gadgets;
	private String s_Num;
	private String m_Name;
	
	public VisitorBean(){
		
	}
	
	
	public VisitorBean(String visitor_Name, String company_Name, String email_ID, String visitor_Mob, String country,
			String visitor_City, String visitor_Adr, String visitor_ID_Prf, String visitor_Prf_Num,
			String visitor_Nationality, String image, String foreign, String status, String r_status,
			String visitor_Num, String gadgets, String s_Num, String m_Name) {
		super();
		this.visitor_Name = visitor_Name;
		this.company_Name = company_Name;
		this.email_ID = email_ID;
		this.visitor_Mob = visitor_Mob;
		this.country = country;
		this.visitor_City = visitor_City;
		this.visitor_Adr = visitor_Adr;
		this.visitor_ID_Prf = visitor_ID_Prf;
		this.visitor_Prf_Num = visitor_Prf_Num;
		this.visitor_Nationality = visitor_Nationality;
		this.image = image;
		this.foreign = foreign;
		this.status = status;
		this.r_status = r_status;
		this.visitor_Num = visitor_Num;
		this.gadgets = gadgets;
		this.s_Num = s_Num;
		this.m_Name = m_Name;
	}


	public String getVisitor_Name() {
		return visitor_Name;
	}

	public void setVisitor_Name(String visitor_Name) {
		this.visitor_Name = visitor_Name;
	}

	public String getCompany_Name() {
		return company_Name;
	}

	public void setCompany_Name(String company_Name) {
		this.company_Name = company_Name;
	}

	public String getEmail_ID() {
		return email_ID;
	}

	public void setEmail_ID(String email_ID) {
		this.email_ID = email_ID;
	}

	public String getVisitor_Mob() {
		return visitor_Mob;
	}

	public void setVisitor_Mob(String visitor_Mob) {
		this.visitor_Mob = visitor_Mob;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getVisitor_City() {
		return visitor_City;
	}

	public void setVisitor_City(String visitor_City) {
		this.visitor_City = visitor_City;
	}

	public String getVisitor_Adr() {
		return visitor_Adr;
	}

	public void setVisitor_Adr(String visitor_Adr) {
		this.visitor_Adr = visitor_Adr;
	}

	public String getVisitor_ID_Prf() {
		return visitor_ID_Prf;
	}

	public void setVisitor_ID_Prf(String visitor_ID_Prf) {
		this.visitor_ID_Prf = visitor_ID_Prf;
	}

	public String getVisitor_Prf_Num() {
		return visitor_Prf_Num;
	}

	public void setVisitor_Prf_Num(String visitor_Prf_Num) {
		this.visitor_Prf_Num = visitor_Prf_Num;
	}

	public String getVisitor_Nationality() {
		return visitor_Nationality;
	}

	public void setVisitor_Nationality(String visitor_Nationality) {
		this.visitor_Nationality = visitor_Nationality;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getForeign() {
		return foreign;
	}

	public void setForeign(String foreign) {
		this.foreign = foreign;
	}

	public String getGadgets() {
		return gadgets;
	}

	public void setGadgets(String gadgets) {
		this.gadgets = gadgets;
	}

	public String getS_Num() {
		return s_Num;
	}

	public void setS_Num(String s_Num) {
		this.s_Num = s_Num;
	}

	public String getM_Name() {
		return m_Name;
	}

	public void setM_Name(String m_Name) {
		this.m_Name = m_Name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getVisitor_Num() {
		return visitor_Num;
	}

	public void setVisitor_Num(String visitor_Num) {
		this.visitor_Num = visitor_Num;
	}

	public void setR_Status(String string) {
		// TODO Auto-generated method stub
		
	}

	public String getR_status() {
		return r_status;
	}

	public void setR_status(String r_status) {
		this.r_status = r_status;
	}
	
	
	
}


