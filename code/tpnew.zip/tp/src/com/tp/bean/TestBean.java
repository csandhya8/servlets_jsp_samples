package com.tp.bean;

public class TestBean {
	
	private String _id;
	private String associate_ID;
	private String associate_Name;
	private String associate_Mob;
	private String visitor_Type;
	private String escorted_By;
	private String host_City;
	private String Associate_Loc;
	private String start_Date;
	private String End_Date;
	private String request_Raised_at;
	private String foreign_Key;
	private int no_Of_Visitors;
	private byte[] imagebuf;
	private String status;
	private String r_Status;
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public byte[] getImagebuf() {
		return imagebuf;
	}

	public void setImagebuf(byte[] imagebuf) {
		this.imagebuf = imagebuf;
	}

	public int getNo_Of_Visitors() {
		return no_Of_Visitors;
	}

	public void setNo_Of_Visitors(int no_Of_Visitors) {
		this.no_Of_Visitors = no_Of_Visitors;
	}
	
	

	public String getR_Status() {
		return r_Status;
	}

	public void setR_Status(String r_Status) {
		this.r_Status = r_Status;
	}

	public TestBean(){
		
	}

	

	public TestBean(String _id, String associate_ID, String associate_Name, String associate_Mob, String visitor_Type,
			String escorted_By, String host_City, String associate_Loc, String start_Date, String end_Date,
			String request_Raised_at, String foreign_Key, int no_Of_Visitors, byte[] imagebuf, String status) {
		super();
		this._id = _id;
		this.associate_ID = associate_ID;
		this.associate_Name = associate_Name;
		this.associate_Mob = associate_Mob;
		this.visitor_Type = visitor_Type;
		this.escorted_By = escorted_By;
		this.host_City = host_City;
		Associate_Loc = associate_Loc;
		this.start_Date = start_Date;
		End_Date = end_Date;
		this.request_Raised_at = request_Raised_at;
		this.foreign_Key = foreign_Key;
		this.no_Of_Visitors = no_Of_Visitors;
		this.imagebuf = imagebuf;
		this.status = status;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String getAssociate_ID() {
		return associate_ID;
	}

	public void setAssociate_ID(String associate_ID) {
		this.associate_ID = associate_ID;
	}

	public String getAssociate_Name() {
		return associate_Name;
	}

	public void setAssociate_Name(String associate_Name) {
		this.associate_Name = associate_Name;
	}

	public String getAssociate_Mob() {
		return associate_Mob;
	}

	public void setAssociate_Mob(String associate_Mob) {
		this.associate_Mob = associate_Mob;
	}

	public String getVisitor_Type() {
		return visitor_Type;
	}

	public void setVisitor_Type(String visitor_Type) {
		this.visitor_Type = visitor_Type;
	}

	public String getEscorted_By() {
		return escorted_By;
	}

	public void setEscorted_By(String escorted_By) {
		this.escorted_By = escorted_By;
	}

	public String getHost_City() {
		return host_City;
	}

	public void setHost_City(String host_City) {
		this.host_City = host_City;
	}

	public String getAssociate_Loc() {
		return Associate_Loc;
	}

	public void setAssociate_Loc(String associate_Loc) {
		Associate_Loc = associate_Loc;
	}

	public String getStart_Date() {
		return start_Date;
	}

	public void setStart_Date(String start_Date) {
		this.start_Date = start_Date;
	}

	public String getEnd_Date() {
		return End_Date;
	}

	public void setEnd_Date(String end_Date) {
		End_Date = end_Date;
	}

	public String getRequest_Raised_at() {
		return request_Raised_at;
	}

	public void setRequest_Raised_at(String request_Raised_at) {
		this.request_Raised_at = request_Raised_at;
	}

	public String getForeign_Key() {
		return foreign_Key;
	}

	public void setForeign_Key(String foreign_Key) {
		this.foreign_Key = foreign_Key;
	}


	
	
}
