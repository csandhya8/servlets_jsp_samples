package com.tp.bean;

public class AdminBean {
	
	public String gid;
	public String pswd;
	public String uname;
	public String IBU;
	
	public AdminBean(){
		
	}
	

	public AdminBean(String gid, String pswd, String uname, String iBU) {
		super();
		this.gid = gid;
		this.pswd = pswd;
		this.uname = uname;
		IBU = iBU;
	}


	public String getGid() {
		return gid;
	}
	public void setGid(String gid) {
		this.gid = gid;
	}
	public String getPswd() {
		return pswd;
	}
	public void setPswd(String pswd) {
		this.pswd = pswd;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getIBU() {
		return IBU;
	}
	public void setIBU(String iBU) {
		IBU = iBU;
	}
	
	

}
