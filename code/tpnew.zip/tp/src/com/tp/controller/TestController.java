package com.tp.controller;

import java.awt.image.BufferedImage;
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.http.Part;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.imageio.ImageIO;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;

import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.oreilly.servlet.MultipartRequest;

import com.tp.bean.TestBean;
import com.tp.bean.VisitorBean;
import com.tp.connection.EditPage;
import com.tp.connection.EditRequest;
import com.tp.connection.QRGenerator;
import com.tp.connection.TestConnection;
import com.tp.connection.ViewRequest;


public class TestController extends HttpServlet{
	
	private static final String UPLOAD_DIRECTORY = "D:/pics";
	String qrCodeData;
	 List<String> qr = new ArrayList<String>();
	
	 
	 private static String[] V_Email_ID;
	 String charset = "UTF-8"; 
	
	 
public void init(ServletConfig sc){
		
		System.out.println("Servlet object created");
		
	} 

public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
	response.setContentType("multipart/form-data");
	
	RequestDispatcher rd = null;
	 
	Date date = new Date();
	String Gtime = date.toString();
	                 
	String module=request.getParameter("module");
	
	System.out.println("module value\t" + module);
	System.out.println("The module value has been printed\n");
	
	
	if(ServletFileUpload.isMultipartContent(request)){
		
		MultipartRequest Mreq = new MultipartRequest(request, UPLOAD_DIRECTORY, 1024 * 1024 * 1024);
		 TestConnection tc =  new TestConnection();
		 TestBean gb = new TestBean();
		 
		 qr.clear();
		HttpSession hs = request.getSession();
	//	String userNo = (String) hs.getAttribute("uname");
		System.out.println("The module value add visitor\n");
		
		String r_ID = (String) hs.getAttribute("f_key");
		String a_ID = (String) hs.getAttribute("f_key");
		
		 String id = tc.retrieve_ID();
	        if(!(id==null)){
			 
		    id = id.substring(9, 15);
		    long l = Long.parseLong(id);
		    r_ID = r_ID.concat("VMS");
		    String num = Long.toString(++l);
		    r_ID = r_ID.concat(num);
		    System.out.println("Final id\t" + r_ID );
		    
	        
	        }else{
	        	
	        	r_ID = a_ID + "VMS700001";
	        }
	
	        
	     //   System.out.println("outside list");
	        FileItemFactory factory = new DiskFileItemFactory();
           ServletFileUpload upload = new ServletFileUpload(factory);
           

           List formItems = null;
			try {
				formItems = upload.parseRequest(request);
			    Iterator iter = formItems.iterator();
			    Enumeration files = Mreq.getFileNames();

		        while (files.hasMoreElements()) {
                    System.out.println("\nHasMoreItems");
		            String name = (String) files.nextElement();
		            String filename = Mreq.getFilesystemName(name);
		            System.out.println(filename);
		        }
			/*while (iter.hasNext()) {
			//	System.out.println("inside list image");
				FileItem item = (FileItem) iter.next();
				if (!item.isFormField()) {
					System.out.println("inside form field");
					String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIRECTORY;
					String fileName = new File(item.getName()).getName();
					String filePath = uploadPath + File.separator + fileName;
					File storeFile = new File(filePath);
					item.write(storeFile);
					System.out.println(item);
					System.out.println(storeFile);
					tc.InsertImage(storeFile, r_ID);
					System.out.println("\n the uploading file's path:\t"+filePath );
				}
			}
			*/} catch (FileUploadException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
  //    System.out.println("\n i am running.....");
		String HostName = Mreq.getParameter("H_name");
		String HostPhone = Mreq.getParameter("H_pno");
		String VisitorType = Mreq.getParameter("type_of_visitor");
		String Escortby = Mreq.getParameter("escort");
		String HostCity = Mreq.getParameter("city");
		String HostLocation = Mreq.getParameter("location");
		String S_date = Mreq.getParameter("startdate");
		String E_date = Mreq.getParameter("enddate");

	
		String[] V_Name = Mreq.getParameterValues("visior_name");
		String[] V_CompanyName = Mreq.getParameterValues("Company_name");
		V_Email_ID = Mreq.getParameterValues("Email_ID");
		String[] V_Mobile_Number = Mreq.getParameterValues("Mobile_Number");
		String[] V_Country = Mreq.getParameterValues("Country");
		String[] V_City = Mreq.getParameterValues("City");
		String[] V_Address = Mreq.getParameterValues("Address");
		String[] V_id_proof = Mreq.getParameterValues("id_proof");
		String[] V_proof_no = Mreq.getParameterValues("Passport");
		String[] V_nationality = Mreq.getParameterValues("Nationality");
	   // File files = Mreq.getFile("UPLOAD");
	  
	   // System.out.println("\n File Names"+files.toString());
		  hs.setAttribute("gid",a_ID);
		    hs.setAttribute("H_name",HostName);
		    hs.setAttribute("H_pno",HostPhone);
		    hs.setAttribute("type_of_visitor",VisitorType);
		    hs.setAttribute("escort",Escortby);
		    hs.setAttribute("city",HostCity);
		    hs.setAttribute("location",HostLocation);
		    hs.setAttribute("startdate",S_date);
		    hs.setAttribute("enddate",E_date);
		    
		    
		    int range = V_Name.length;
		    
		    hs.setAttribute("range",range);
				 			 
				 try{
						
						gb.setAssociate_ID(a_ID);
						gb.setAssociate_Name(HostName);
						gb.setAssociate_Mob(HostPhone);
						gb.setVisitor_Type(VisitorType);
						gb.setEscorted_By(Escortby);
						gb.setHost_City(HostCity);
						gb.setAssociate_Loc(HostLocation);
						gb.setStart_Date(S_date);
						gb.setEnd_Date(E_date);
						gb.setRequest_Raised_at(Gtime);
						gb.setForeign_Key(r_ID);
						gb.setNo_Of_Visitors(range);
						gb.setStatus("submitted");
						gb.setR_Status("not_visited");
						
						 hs.setAttribute("r_ID",r_ID);
						String f_ID = tc.DBinsert(gb,r_ID);
						
						System.out.println("\n the f_ID is:\t"+ f_ID);

						
					 VisitorBean vb = new VisitorBean();
					 
					 for(int i=0;i<V_Name.length;i++){
						 
						 System.out.println("visitor length "+V_Name.length);
							int n = i+1;
					vb.setForeign(f_ID); 
					vb.setVisitor_Name(V_Name[i]);
					vb.setCompany_Name(V_CompanyName[i]);
					vb.setEmail_ID(V_Email_ID[i]);
					vb.setVisitor_Mob(V_Mobile_Number[i]);
					vb.setCountry(V_Country[i]);
					vb.setVisitor_City(V_City[i]);
					vb.setVisitor_Adr(V_Address[i]);
					vb.setVisitor_ID_Prf(V_id_proof[i]);
					vb.setVisitor_Prf_Num(V_proof_no[i]);
					vb.setVisitor_Nationality(V_nationality[i]);
	               vb.setVisitor_Num("visitor_"+n);
	               
					
					 
					 tc.visitorAdd(vb,f_ID);

					 File index = new File("D:/qrcode/"+r_ID);
						if (index.exists()) {
						String[]entries = index.list();
						for(String s: entries){
						    File currentFile = new File(index.getPath(),s);
						    currentFile.delete();
						}
						}
						index.mkdir();


					 qrCodeData = "\n"+"Visitor name:"+V_Name[i]+"\n"+"visitor company:"+V_CompanyName[i]+"\n"+"visitor mobile:"+V_Mobile_Number[i]+
							 "\n"+"proof:"+V_proof_no[i]+"\n"+"associate ID:"+a_ID+"\n"+"associate name"+HostName;
					 System.out.println("qrCodeData:\t" + qrCodeData);
					 qr.add(qrCodeData);
				 
						
					}
					 }catch(Exception we)
				{
						we.printStackTrace();
				}
				 
				// TestConnection tc =  new TestConnection();
				 
				 List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
				 System.out.println("\n retrieve list func gonna be executed...........");
					
				 viewList = tc.retrieveList(range,r_ID);
				 System.out.println("\n retrieve list func stopped...........");

				 
				 rd = request.getRequestDispatcher("raising Request_1.jsp");
				 request.setAttribute("Listview", viewList);
				 rd.forward(request, response);
									 
				 request.setAttribute("message", "Upload has been done successfully!");
	      	       
	    }
	    
	
	else if(module.equals("login")){
		HttpSession hs = request.getSession(true);
		
        String uname = request.getParameter("user");
        String pswd = request.getParameter("pass");
        String login = request.getParameter("login");
        System.out.println("\n the value of login is:\t"+login);
        
       
        hs.setAttribute("uname",uname);
        String userNo = (String) hs.getAttribute("uname");
        String f_key = userNo.substring(4);
        hs.setAttribute("f_key",f_key);
       
        TestConnection tc =  new TestConnection();
        if(tc.validate(uname, pswd,login)){
        	
        	String[] detail = new String[3];
        	detail = tc.getDetails(uname, pswd,login);
            System.out.println("Login Successfull...\n");
            hs.setAttribute("user", detail[0]);
            String user = (String) hs.getAttribute("user");
            System.out.println("\n the value of user is:\t"+user);
            hs.setAttribute("ibu", detail[1]);
            String ibu = (String) hs.getAttribute("ibu");
           
            if(user.equals("Security")){
            	System.out.println("\n Entered Security if block");
            	 hs.setAttribute("SecLoc", detail[2]);
            	 System.out.println("Security Location:" + detail[2]);
            	 rd = request.getRequestDispatcher("security_page.jsp");
            
                rd.forward(request,response);
            }else if(user.equals("Admin")){
            	
            	System.out.println("\n Entered Admin if block");
           	 hs.setAttribute("SecLoc", detail[2]);
           	 System.out.println("Security Location:" + detail[2]);
           	rd = request.getRequestDispatcher("Admin_page.jsp");
           
               rd.forward(request,response);
               
            }else{
            	 rd = request.getRequestDispatcher("myPage.jsp");
                 
                 rd.forward(request,response);
            }
           
                   }
        else{
            System.out.println("Couldn't login\n");
            request.setAttribute("EmptyText","Invalid Username or Password");    
            rd = request.getRequestDispatcher("login.jsp");
            rd.forward(request,response);
            System.out.println("rd value:\t"+rd);
    }
	}
	
/*	if(module.equals("visitor_add")){
		qr.clear();
		HttpSession hs = request.getSession();
	//	String userNo = (String) hs.getAttribute("uname");
		System.out.println("The module value add visitor\n");
		
		String r_ID = (String) hs.getAttribute("f_key");
		String a_ID = (String) hs.getAttribute("f_key");
		
		String uploadPath = getServletContext().getRealPath("")
				+ File.separator + UPLOAD_DIRECTORY;
		
		MultipartRequest Mreq = new MultipartRequest(request, uploadPath, 1024 * 1024 * 1024);
		
		System.out.println("\n i am running.....");
		String HostName = request.getParameter("H_name");
		String HostPhone = request.getParameter("H_pno");
		String VisitorType = request.getParameter("type_of_visitor");
		String Escortby = request.getParameter("escort");
		String HostCity = request.getParameter("city");
		String HostLocation = request.getParameter("location");
		String S_date = request.getParameter("startdate");
		String E_date = request.getParameter("enddate");
	
	
		String[] V_Name = request.getParameterValues("visior_name");
		String[] V_CompanyName = request.getParameterValues("Company_name");
		V_Email_ID = request.getParameterValues("Email_ID");
		String[] V_Mobile_Number = request.getParameterValues("Mobile_Number");
		String[] V_Country = request.getParameterValues("Country");
		String[] V_City = request.getParameterValues("City");
		String[] V_Address = request.getParameterValues("Address");
		String[] V_id_proof = request.getParameterValues("id_proof");
		String[] V_proof_no = request.getParameterValues("Passport");
		String[] V_nationality = request.getParameterValues("Nationality");
		String appPath = request.getServletContext().getRealPath("UPLOAD");
		System.out.println("\nuploaded file "+ appPath);
		 String savePath = appPath + File.separator + "D:/Backup/uploads";
		 System.out.println("\n file save path "+ appPath);
		 
		 File fileSaveDir = new File(savePath);
		 if (!fileSaveDir.exists())
		 {
		  fileSaveDir.mkdir();
		 } 

		 for (Part part : request.getParts()) 
		 {
			   
		       String fileName = extractFileName(part);
		     
		       fileName = new File(fileName).getName();
		       part.write(savePath + File.separator + fileName);
		 }
		 
		 request.setAttribute("message", "Upload has been done successfully!");
		
		 Part filePart = request.getPart("UPLOAD"); 
	   if(filePart!= null){
		   System.out.println(filePart.getName());
           System.out.println(filePart.getSize());
           System.out.println(filePart.getContentType());
	   }
	   
        hs.setAttribute("gid",a_ID);
	    hs.setAttribute("H_name",HostName);
	    hs.setAttribute("H_pno",HostPhone);
	    hs.setAttribute("type_of_visitor",VisitorType);
	    hs.setAttribute("escort",Escortby);
	    hs.setAttribute("city",HostCity);
	    hs.setAttribute("location",HostLocation);
	    hs.setAttribute("startdate",S_date);
	    hs.setAttribute("enddate",E_date);
	    
	    
	    int range = V_Name.length;
	    
	    hs.setAttribute("range",range);
			 			 
			 try{
				 				
				 TestConnection tc =  new TestConnection();
			        TestBean gb = new TestBean();
					
			        String id = tc.retrieve_ID();
			        if(!(id==null)){
					 
				    id = id.substring(9, 15);
				    long l = Long.parseLong(id);
				    r_ID = r_ID.concat("VMS");
				    String num = Long.toString(++l);
				    r_ID = r_ID.concat(num);
				    System.out.println("Final id\t" + r_ID );
				    
			        
			        }else{
			        	
			        	r_ID = a_ID + "VMS700001";
			        }
					
					gb.setAssociate_ID(a_ID);
					gb.setAssociate_Name(HostName);
					gb.setAssociate_Mob(HostPhone);
					gb.setVisitor_Type(VisitorType);
					gb.setEscorted_By(Escortby);
					gb.setHost_City(HostCity);
					gb.setAssociate_Loc(HostLocation);
					gb.setStart_Date(S_date);
					gb.setEnd_Date(E_date);
					gb.setRequest_Raised_at(Gtime);
					gb.setForeign_Key(r_ID);
					gb.setNo_Of_Visitors(range);
					gb.setStatus("submitted");
					gb.setR_Status("not_visited");
					
					 hs.setAttribute("r_ID",r_ID);
					String f_ID = tc.DBinsert(gb,r_ID);
					
					System.out.println("\n the f_ID is:\t"+ f_ID);

					
				 VisitorBean vb = new VisitorBean();
				 
				 for(int i=0;i<V_Name.length;i++){
					 
					 System.out.println("visitor length "+V_Name.length);
						int n = i+1;
				vb.setForeign(f_ID); 
				vb.setVisitor_Name(V_Name[i]);
				vb.setCompany_Name(V_CompanyName[i]);
				vb.setEmail_ID(V_Email_ID[i]);
				vb.setVisitor_Mob(V_Mobile_Number[i]);
				vb.setCountry(V_Country[i]);
				vb.setVisitor_City(V_City[i]);
				vb.setVisitor_Adr(V_Address[i]);
				vb.setVisitor_ID_Prf(V_id_proof[i]);
				vb.setVisitor_Prf_Num(V_proof_no[i]);
				vb.setVisitor_Nationality(V_nationality[i]);
                vb.setVisitor_Num("visitor_"+n);
                
				
				 
				 tc.visitorAdd(vb,f_ID);

				 File index = new File("D:/qrcode/"+r_ID);
					if (index.exists()) {
					String[]entries = index.list();
					for(String s: entries){
					    File currentFile = new File(index.getPath(),s);
					    currentFile.delete();
					}
					}
					index.mkdir();


				 qrCodeData = "\n"+"Visitor name:"+V_Name[i]+"\n"+"visitor company:"+V_CompanyName[i]+"\n"+"visitor mobile:"+V_Mobile_Number[i]+
						 "\n"+"proof:"+V_proof_no[i]+"\n"+"associate ID:"+a_ID+"\n"+"associate name"+HostName;
				 qr.add(qrCodeData);
			 
					
				}
				 }catch(Exception we)
			{
					we.printStackTrace();
			}
			 
			 TestConnection tc =  new TestConnection();
			 
			 List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
			 System.out.println("\n retrieve list func gonna be executed...........");
				viewList = tc.retrieveList(range,r_ID);
				 System.out.println("\n retrieve list func stopped...........");

			 
			 rd = request.getRequestDispatcher("raising Request_1.jsp");
			 request.setAttribute("Listview", viewList);
				rd.forward(request, response);
								 
			
	}*/
	
	
	else if (module.equals("retrieve")){
		HttpSession hs = request.getSession();
		
		 rd = request.getRequestDispatcher("Gadgets.jsp");
			
			rd.forward(request, response);
		
	}
	
	else if (module.equals("update")){
		
		HttpSession hs = request.getSession();
		String a_ID = (String) hs.getAttribute("f_key");
		String r_ID = (String) hs.getAttribute("r_ID");
		VisitorBean tb = new VisitorBean();

		String[] gadgets = request.getParameterValues("gadgets");
		String[] s_num = request.getParameterValues("sno");
		String[] m_Name = request.getParameterValues("manufacturer");
		String[] visitorno = request.getParameterValues("visitorno");
		
		
		for(int i=0;i<gadgets.length;i++){
			System.out.println("gadgets length "+gadgets.length);
			int range = (int) hs.getAttribute("range");
			
		tb.setGadgets(gadgets[i]);
		tb.setS_Num(s_num[i]);
		tb.setM_Name(m_Name[i]);
		
		TestConnection tc =  new TestConnection();
		tc.DBupdate(tb,visitorno[i],r_ID,range);
		
		
		int a= Integer.parseInt(visitorno[i].substring(8));

			String addData = "\n"+"gadget:"+gadgets[i]+"\n"+"serial no:"+s_num[i]+"\n"+"manufacturer:"+m_Name[i];  
			System.out.println("iterative a value" + a);
			String data = qr.get(--a);
			System.out.println("List data:"+data);
			
			addData = data.concat(addData);
			
			qr.set(a,addData);
		}
		Iterator itr = qr.iterator();
		int i=0;
		while(itr.hasNext()){
			System.out.println("qr.get " + itr.next());
			try {
				main(qr.get(i),V_Email_ID[i]);
			} catch (NotFoundException | WriterException e) {
				
				e.printStackTrace();
			}
			
			System.out.println("value of i in while loop " + ++i);
	}
	
   

	qr.clear();
	rd = request.getRequestDispatcher("rid.jsp");
	
	rd.forward(request, response);
}
			 

	else if (module.equals("view")){
		HttpSession hs = request.getSession();
		String a_ID = (String) hs.getAttribute("f_key");
		
		
		List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
		
		String view[] = new String[6];
		view[0] = request.getParameter("type_of_visitor");
		view[1] = request.getParameter("status");
		view[2] = request.getParameter("startdate");
		view[3] = request.getParameter("enddate");
		view[4] = request.getParameter("H_pno");
		view[5] = a_ID;
		
		 hs.setAttribute("status",view[1]);
		 hs.setAttribute("v_Type",view[0]);
		 hs.setAttribute("s_date",view[2] );
		 hs.setAttribute("e_date",view[3] );
		 hs.setAttribute("mob",view[4] );
		 
		 
		 ViewRequest get = new ViewRequest();
		
		 viewList = get.retrieveToView(view,a_ID);
		
		 rd = request.getRequestDispatcher("viewRequest_1.jsp");
		 request.setAttribute("Listview", viewList);
		 
			rd.forward(request, response);
	}
	
	else if (module.equals("security_view")||module.equals("security_viewedit")){
		HttpSession hs = request.getSession();
		
		String view[] = new String[5];
		view[0] = request.getParameter("vname");
		view[1] = request.getParameter("id_proof");
		view[2] = request.getParameter("H_pno");
		view[3] = request.getParameter("rid");
		view[4] =  (String) hs.getAttribute("SecLoc");
		System.out.println("view[4] value:" + view[4]);
		
		ViewRequest get = new ViewRequest();
		List<BasicDBObject> viewList_1 = new ArrayList<BasicDBObject>();
		viewList_1= get.retrieveToView_1(view);
		
		if(module.equals("security_viewedit")){
			System.out.println("\n enters Security_viewedit");
			rd = request.getRequestDispatcher("Security_vieweditpage_1.jsp");
			request.setAttribute("Listview_1", viewList_1);
			rd.forward(request, response);
			 
		}else{
		
		rd = request.getRequestDispatcher("security_view_1.jsp");
		request.setAttribute("Listview_1", viewList_1);
		 
		rd.forward(request, response);
		}
	}
	
	else if (module.equals("request_record")){
		HttpSession hs = request.getSession();
		String user = (String) hs.getAttribute("user");
		String view[] = new String[5];
		view[0] = request.getParameter("vname");
		view[1] = request.getParameter("id_proof");
		view[2] = request.getParameter("H_pno");
		view[3] = request.getParameter("rid");
		view[4] =  (String) hs.getAttribute("SecLoc");
		String Report = request.getParameter("startdate");
		System.out.println("\n the value of report:\t"+Report);
		ViewRequest get = new ViewRequest();
		List<BasicDBObject> viewList_1 = new ArrayList<BasicDBObject>();
		
			viewList_1= get.retrieveToView_2(view,Report);

		
		rd = request.getRequestDispatcher("request_record_1.jsp");
		request.setAttribute("Listview_1", viewList_1);
		 
		rd.forward(request, response);
		
	}

	/*if (module.equals("Admin_Reports")){
		
		HttpSession hs = request.getSession();
		ViewRequest get = new ViewRequest();
		List<BasicDBObject> viewList_1 = new ArrayList<BasicDBObject>();
		
			viewList_1= get.admin_View();
			 rd = request.getRequestDispatcher("Admin_View_1.jsp");
			 request.setAttribute("editList", viewList_1);
				rd.forward(request, response);
			
	
	}*/
	else if (module.equals("edit")){
		HttpSession hs = request.getSession();
		String a_ID = (String) hs.getAttribute("f_key");		
		List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
		
		String view[] = new String[6];
		view[0] = request.getParameter("type_of_visitor");
		view[1] = request.getParameter("status");
		view[2] = request.getParameter("startdate");
		view[3] = request.getParameter("enddate");
		view[4] = request.getParameter("H_pno");
		view[5] = a_ID;
		
		 hs.setAttribute("status",view[1]);
		 hs.setAttribute("v_Type",view[0]);
		 hs.setAttribute("s_date",view[2] );
		 hs.setAttribute("e_date",view[3] );
		 hs.setAttribute("mob",view[4] );
		 
		 EditRequest er = new EditRequest();
			viewList = er.retrieveToView(view,a_ID);
			System.out.println("\n the size of edit modules ViewList:\t"+viewList.size());
		
		 rd = request.getRequestDispatcher("editRequest_1.jsp");
		 request.setAttribute("editList", viewList);
			rd.forward(request, response);
		
		
	}
	
	
	else if (module.equals("view_Record")){
		HttpSession hs = request.getSession();
		String r_ID = (String) hs.getAttribute("r_ID");
		String user = (String) hs.getAttribute("user");
		String value = request.getParameter("submit");
		hs.setAttribute("qrCode",value);
		hs.setAttribute("Status_RID",value);
		
		System.out.println("\n the value of submit is:\t"+value );

		System.out.println("\n the value of submit: \t"+value);
		TestConnection tc = new TestConnection();
		
		 List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
		 List<BasicDBObject> viewList_1 = new ArrayList<BasicDBObject>();
		
		 viewList = tc.recordRetrieve(value);
		 viewList_1 = tc.recordRetrieve_1(value);
		 for(int i=0;i<viewList.size();i++){
		    	System.out.println(viewList_1.get(i));
		    }
		 if(user.equals("Security")){
	        	rd = request.getRequestDispatcher("Security_Record_view.jsp");
	            
	        }else{
		rd = request.getRequestDispatcher("RecordView.jsp");
	        }
		 
		
		int size  = viewList.size();
		System.out.println("\n the value of size is:\t"+size);
		int size_1  = viewList_1.size();
		System.out.println("\n the value of size is:\t"+size_1);
		hs.setAttribute("list",size);
		hs.setAttribute("list_1",size_1);
		
		request.setAttribute("Listview", viewList);
		request.setAttribute("Listview_1", viewList_1);
			rd.forward(request, response);
		
	}
	
	else if (module.equals("request_record_view")){
		HttpSession hs = request.getSession();
		
		String value = request.getParameter("submit");
		hs.setAttribute("qrCode",value);
		hs.setAttribute("Status_RID",value);
		
		System.out.println("\n the value of submit is:\t"+value );

		System.out.println("\n the value of submit: \t"+value);
		TestConnection tc = new TestConnection();
		
		 List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
		 List<BasicDBObject> viewList_1 = new ArrayList<BasicDBObject>();
		
		 viewList = tc.recordRetrieve(value);
		 viewList_1 = tc.recordRetrieve_1(value);
		 for(int i=0;i<viewList.size();i++){
		    	System.out.println(viewList_1.get(i));
		    }
		 
	        	request.setAttribute("Listview", viewList);
	    		request.setAttribute("Listview_1", viewList_1);
	    		rd = request.getRequestDispatcher("request_record_view.jsp");
	    		System.out.println("\n the value of rd:\t"+rd);
	        	rd.forward(request, response);
	}
	
	
	else if (module.equals("qrgen") || module.equals("passDetails")){
		HttpSession hs = request.getSession();
		
		
		String qrCode = (String) hs.getAttribute("qrCode");
		System.out.println("\n the value of qrcode:\t"+qrCode);
		String v_num = request.getParameter("submit");
		System.out.println("\n the value of v_num:\t"+v_num);
		List<BasicDBObject> qrList = new ArrayList<BasicDBObject>();
		QRGenerator qr = new QRGenerator();
		qrList = qr.QRRecord(qrCode,v_num);
		BasicDBObject a_detail = qrList.get(0);
		BasicDBObject details = qrList.get(1);
		
		String Ready_qr = "\n visitor_Name:"+details.get("visitor_Name")+"\n visitor_Company:"+details.get("company_Name")+
		"\n visitor_mobile:"+details.get("visitor_Mob")+"\n visitor_ID:"+details.get("visitor_ID_Prf")+"\n visitor_ID_Num:"+details.get("visitor_Prf_Num")+"\n"+"associate ID:"+a_detail.get("associate_ID")
		+"\n"+"associate name"+a_detail.get("associate_Name")+"\n"+"gadget:"+details.get("gadgets")+"\n"+"serial no:"+details.get("s_Num")+"\n"+"manufacturer:"+details.get("m_Name");

		
		 
	if(module.equals("qrgen")){
			 try {
				 main(Ready_qr, (String)details.get("email_ID") );
				} catch (NotFoundException | WriterException e) {
					
					e.printStackTrace();
				}
			
			 rd = request.getRequestDispatcher("MailSuccess.jsp");
				
				rd.forward(request, response);
		 }
		 else if(module.equals("passDetails")){
			 Map<EncodeHintType, ErrorCorrectionLevel> hintMap = new HashMap<EncodeHintType, ErrorCorrectionLevel>();
			 hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);

			 BufferedImage src = null;
			try {
				src = createQRCode(Ready_qr, charset, hintMap, 50, 50);
			} catch (WriterException e) {
				
				e.printStackTrace();
			}
			 ByteArrayOutputStream baos = new ByteArrayOutputStream();
			 ImageIO.write( src, "jpg", baos );
			 baos.flush();
			 byte[] imageInByteArray = baos.toByteArray();
			 baos.close();
			 String b64 = javax.xml.bind.DatatypeConverter.printBase64Binary(imageInByteArray);
			 hs.setAttribute("image", b64);
			 request.setAttribute("associate", a_detail);
			 request.setAttribute("visitor", details);
			 rd = request.getRequestDispatcher("printPass.jsp");
				rd.forward(request, response);
		 }
		   
	}
	
	else if (module.equals("edit_Record")||module.equals("editview_Record")){
		HttpSession hs = request.getSession();
	
		String value = request.getParameter("submit");
		System.out.println("\n the value of submit: \t"+value);
		TestConnection tc = new TestConnection();
		
		 List<BasicDBObject> editList = new ArrayList<BasicDBObject>();
		 
		
		 editList = tc.edit(value);
		 hs.setAttribute("edit_ID",value);
		 if(module.equals("editview_Record")){
			 rd = request.getRequestDispatcher("Security_EditPage.jsp");
		 }else{
		
		rd = request.getRequestDispatcher("EditPage.jsp");
		 }
		int size  = editList.size();
		System.out.println("\n the value of size is:\t"+size);
		
		
		hs.setAttribute("edit",size);
		
		request.setAttribute("editList", editList);
		
			rd.forward(request, response);
		
	}
	else if (module.equals("editing")||module.equals("S_edit")){
		HttpSession hs = request.getSession();
		
		String edit_ID = (String) hs.getAttribute("edit_ID");
		
		List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
		
		String Host_Id = request.getParameter("gid");
		hs.setAttribute("edit_associate_ID", Host_Id);
		String Host_Name = request.getParameter("h_Name");
		hs.setAttribute("edit_associate_Name", Host_Name);
		
		String HostPhone = request.getParameter("H_pno");
		String VisitorType = request.getParameter("v_type");
		String Escortby = request.getParameter("escort");
		String HostCity = request.getParameter("city");
		String HostLocation = request.getParameter("location");
		String S_date = request.getParameter("startdate");
		String E_date = request.getParameter("enddate");
		String v_Num = request.getParameter("total_visitor");
		int v_no = Integer.parseInt(v_Num);
		
		TestBean gb = new TestBean();
		
		gb.setAssociate_Mob(HostPhone);
		gb.setVisitor_Type(VisitorType);
		gb.setEscorted_By(Escortby);
		gb.setHost_City(HostCity);
		gb.setAssociate_Loc(HostLocation);
		gb.setStart_Date(S_date);
		gb.setEnd_Date(E_date);
		gb.setRequest_Raised_at(Gtime);
		gb.setNo_Of_Visitors(v_no);
		
		EditPage ep = new EditPage();
		ep.DBupdate(gb, edit_ID);
		viewList = ep.recordRetrieve_1(edit_ID);
	
		int recordSize = viewList.size();
		 hs.setAttribute("recordSize",recordSize);
		 if(module.equals("S_edit")){
			 rd = request.getRequestDispatcher("Security_EditVisitor.jsp");
				request.setAttribute("select",viewList);
				rd.forward(request, response);

		 }else{

		rd = request.getRequestDispatcher("Edit_Visitor.jsp");
		request.setAttribute("select",viewList);
		rd.forward(request, response);
		
		 }
	}
	
	else if (module.equals("status")){

		HttpSession hs = request.getSession();
		
		String Status_RID = (String) hs.getAttribute("qrCode");
		System.out.println("\n the value of Status_RID:\t"+Status_RID);
		String close_ID = request.getParameter("submit");
		hs.setAttribute("v_ID", close_ID);
		String v_close = (String) hs.getAttribute("v_ID");
		System.out.println("\n the value of close_ID:\t"+close_ID);
		EditPage ep = new EditPage();
		ep.Close_Request(Status_RID, close_ID);
		rd = request.getRequestDispatcher("close_page.jsp");
		rd.forward(request, response);

	}

	else if (module.equals("v_edit")||module.equals("Se_edit")){
		HttpSession hs = request.getSession();
		
		String edit_ID = (String) hs.getAttribute("edit_ID");
		
		List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
		
		
		
		String get_ID = request.getParameter("visitorno");
		System.out.println("\n the visitor num ryt after edit page is:"+get_ID);
		hs.setAttribute("get_ID", get_ID);
		
		EditPage ep = new EditPage();
		
		viewList = ep.recordRetrieve_2(edit_ID,get_ID);
		
		if(module.equals("Se_edit")){
			rd = request.getRequestDispatcher("Security_EditVisitor_1.jsp");
			
		}else{
		
		rd = request.getRequestDispatcher("Edit_Visitor_1.jsp");
		
		}
		request.setAttribute("select1",viewList);
		rd.forward(request, response);
	}
	
	else if (module.equals("v_editing")||module.equals("S_editing")){
		HttpSession hs = request.getSession();
		String edit_ID = (String) hs.getAttribute("edit_ID");
		String Host_Id = (String) hs.getAttribute("edit_associate_ID");
		String Host_Name = (String) hs.getAttribute("edit_associate_Name");
		
		String get_ID = (String) hs.getAttribute("get_ID");
		if(get_ID=="" || get_ID==null){
			get_ID = "visitor_1";
			hs.setAttribute("get_ID", get_ID);
		}
		System.out.println("\n the visitor num for editing detail is:"+get_ID);
		
		
		String V_Name = request.getParameter("v_Name");
		String V_CompanyName = request.getParameter("comp");
		String V_Email_ID = request.getParameter("email");
		String V_Mobile_Number = request.getParameter("mob");
		String V_Country = request.getParameter("country");
		String V_City = request.getParameter("city");
		String V_Address = request.getParameter("adrs");
		String V_id_proof = request.getParameter("id");
		String V_proof_no = request.getParameter("id_No");
		String V_nationality = request.getParameter("Nationality");
		
		String gadgets = request.getParameter("gadgets");
		String s_num = request.getParameter("sno");
		String m_Name = request.getParameter("manufacturer");
		
		String qrData = "\n visitor_Name:"+V_Name+"\n visitor_Company:"+V_CompanyName+
				"\n visitor_ID:"+V_id_proof+"\n visitor_ID_Num:"+V_proof_no+"\n visitor_Gadgets:"+gadgets+"\n Serial_Number:"+s_num+
				"\n Manufacturer:"+m_Name+"\n associate_Id:"+Host_Id+"\n associate_Name:"+Host_Name;
	
		 VisitorBean vb = new VisitorBean();
		 
		 List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();
		
		vb.setVisitor_Name(V_Name);
		vb.setCompany_Name(V_CompanyName);
		vb.setEmail_ID(V_Email_ID);
		vb.setVisitor_Mob(V_Mobile_Number);
		vb.setCountry(V_Country);
		vb.setVisitor_City(V_City);
		vb.setVisitor_Adr(V_Address);
		vb.setVisitor_ID_Prf(V_id_proof);
		vb.setVisitor_Prf_Num(V_proof_no);
		vb.setVisitor_Nationality(V_nationality);
        vb.setGadgets(gadgets);
        vb.setS_Num(s_num);
        vb.setM_Name(m_Name);
        
		
		
		 
		 EditPage ep = new EditPage();
		 ep .v_Update(vb,edit_ID,get_ID);
		 
		 try {
				main(qrData,V_Email_ID);
			} catch (NotFoundException | WriterException e) {
				
				e.printStackTrace();
			}
		 
		 viewList = ep.recordRetrieve_2(edit_ID,get_ID);
         System.out.println("Size of EDIT VISITOR 1 ku pora list:"+viewList.size());
         if(module.equals("S_editing")){
        	 rd = request.getRequestDispatcher("Security_EditVisitor_1.jsp");
     		request.setAttribute("select1",viewList);
     		rd.forward(request, response);
         }else{
        	 rd = request.getRequestDispatcher("Edit_Visitor_1.jsp");
     		request.setAttribute("select1",viewList);
     		rd.forward(request, response);
         }
		
	}
if(module.equals("rid_2")){
	HttpSession hs = request.getSession();
	String edit_ID = (String) hs.getAttribute("edit_ID");
	rd = request.getRequestDispatcher("rid_2.jsp");
	
	rd.forward(request, response);
	
}
if(module.equals("rid_3")){
HttpSession hs = request.getSession();

String RID_E = (String) hs.getAttribute("RID_E");

rd = request.getRequestDispatcher("rid_3.jsp");



rd.forward(request, response);



}



if(module.equals("existingRequest")){

HttpSession hs = request.getSession();

String a_ID = (String) hs.getAttribute("f_key");

List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();

String view[] = new String[5];

view[0] = request.getParameter("vname");

view[1] = request.getParameter("H_pno");

view[2] = request.getParameter("id_proof");

view[3] = request.getParameter("rid");

view[4] = a_ID;



if(!(view[0] == "" && view[1] == "" && view[2] == "" && view[3] == "")){

ViewRequest get = new ViewRequest();

viewList = get.retrieveExisting(view);

System.out.println("\n the size of existingRequest viewList:\t"+viewList.size());

rd = request.getRequestDispatcher("usingExisting_1.jsp");

request.setAttribute("Listview", viewList);

rd.forward(request, response);

}

else{



request.setAttribute("Alert","please enter atleast one input");    

rd = request.getRequestDispatcher("usingExisting.jsp");

rd.forward(request,response);



}

hs.setAttribute("vname",view[0]);

hs.setAttribute("H_pno",view[1]);

hs.setAttribute("id_proof",view[2] );

hs.setAttribute("rid",view[3] );

}



if(module.equals("view_Existing")){

HttpSession hs = request.getSession();

String value_1 = request.getParameter("submit");

TestConnection tc = new TestConnection();



List<BasicDBObject> editList = new ArrayList<BasicDBObject>();





 editList = tc.edit(value_1);

hs.setAttribute("edit_ID_E",value_1);



rd = request.getRequestDispatcher("view_Existing.jsp");



request.setAttribute("editList_E", editList);



                rd.forward(request, response);



}





if (module.equals("editing_E")){

HttpSession hs = request.getSession();



String edit_ID_E = (String) hs.getAttribute("edit_ID_E");

String r_ID = (String) hs.getAttribute("f_key");

String a_ID = (String) hs.getAttribute("f_key");



List<BasicDBObject> viewList = new ArrayList<BasicDBObject>();



String Host_Id = request.getParameter("gid");

hs.setAttribute("edit_associate_ID", Host_Id);

String Host_Name = request.getParameter("h_Name");

hs.setAttribute("edit_associate_Name", Host_Name);



String HostPhone = request.getParameter("H_pno");

String VisitorType = request.getParameter("v_type");

String Escortby = request.getParameter("escort");

String HostCity = request.getParameter("city");

String HostLocation = request.getParameter("location");

String S_date = request.getParameter("startdate");

String E_date = request.getParameter("enddate");

String v_Num = request.getParameter("total_visitor");

int v_no = Integer.parseInt(v_Num);



TestConnection tc =  new TestConnection();

TestBean gb = new TestBean();



String id = tc.retrieve_ID();

if(!(id==null)){



id = id.substring(9);

long l = Long.parseLong(id);

r_ID = r_ID.concat("VMS");

String num = Long.toString(++l);

r_ID = r_ID.concat(num);


}else{



r_ID = a_ID + "VMS000001";

}

gb.setAssociate_ID(Host_Id);

gb.setAssociate_Name(Host_Name);

gb.setAssociate_Mob(HostPhone);

gb.setVisitor_Type(VisitorType);

gb.setEscorted_By(Escortby);

gb.setHost_City(HostCity);

gb.setAssociate_Loc(HostLocation);

gb.setStart_Date(S_date);

gb.setEnd_Date(E_date);

gb.setRequest_Raised_at(Gtime);

gb.setNo_Of_Visitors(v_no);

gb.setForeign_Key(r_ID);



EditPage ep = new EditPage();

try {

                tc.DBinsert(gb, r_ID);

} catch (Exception e) {

                e.printStackTrace();

}



hs.setAttribute("rid_E", r_ID);



                               

                                viewList = ep.recordRetrieve_1(edit_ID_E);

                               

                                int recordSize_E = viewList.size();

                                hs.setAttribute("recordSize_E",recordSize_E);



                                rd = request.getRequestDispatcher("select_Visitor.jsp");

                                request.setAttribute("select_E",viewList);

                                rd.forward(request, response);

}



if (module.equals("v_edit_E")){

HttpSession hs = request.getSession();



String edit_ID_E = (String) hs.getAttribute("edit_ID_E");



List<BasicDBObject> viewList_E = new ArrayList<BasicDBObject>();







String get_ID = request.getParameter("visitorno");

System.out.println("\n the parameter is:"+get_ID);

hs.setAttribute("get_ID", get_ID);



EditPage ep = new EditPage();



viewList_E = ep.recordRetrieve_2(edit_ID_E,get_ID);







rd = request.getRequestDispatcher("select_Visitor_1.jsp");

request.setAttribute("select1_E",viewList_E);

rd.forward(request, response);





}



if (module.equals("v_editing_E")){



HttpSession hs = request.getSession();

String get_ID = request.getParameter("visitorno");



String visitorno = (String) hs.getAttribute("get_ID");

System.out.println("\n the value of visitor"+visitorno);

String RID_E = (String) hs.getAttribute("rid_E");

String a_ID = (String) hs.getAttribute("f_key");

String user = (String) hs.getAttribute("user");

String edit_ID_E = (String) hs.getAttribute("edit_ID_E");



String V_Name = request.getParameter("v_Name");

String V_CompanyName = request.getParameter("comp");

String V_Email_ID = request.getParameter("email");

String V_Mobile_Number = request.getParameter("mob");

String V_Country = request.getParameter("country");

String V_City = request.getParameter("city");

String V_Address = request.getParameter("adrs");

String V_id_proof = request.getParameter("id");

String V_proof_no = request.getParameter("id_No");

String V_nationality = request.getParameter("Nationality");

String file = request.getParameter("pic");

String gadgets = request.getParameter("gadgets");

String s_num = request.getParameter("sno");

String m_Name = request.getParameter("manufacturer");

String status = request.getParameter("submit");



VisitorBean vb = new VisitorBean();



vb .setForeign(RID_E);

vb.setVisitor_Name(V_Name);

vb.setCompany_Name(V_CompanyName);

vb.setEmail_ID(V_Email_ID);

vb.setVisitor_Mob(V_Mobile_Number);

vb.setCountry(V_Country);

vb.setVisitor_City(V_City);

vb.setVisitor_Adr(V_Address);

vb.setVisitor_ID_Prf(V_id_proof);

vb.setVisitor_Prf_Num(V_proof_no);

vb.setVisitor_Nationality(V_nationality);

vb.setVisitor_Num(visitorno);

vb.setGadgets(gadgets);

vb.setS_Num(s_num);

vb.setM_Name(m_Name);

vb.setStatus(status);







EditRequest er = new EditRequest();

er.visitorAdd_E(vb,RID_E);



System.out.println("\n the visitor details got added");



String qrCodeData_E = "\n visitor_Name:"+V_Name+"\n visitor_Company:"+V_CompanyName+"\n visitor_ID:"

                                +V_id_proof+"\n visitor_ID_Num:"+V_proof_no+"\n"+"associate ID:"+

a_ID+"\n"+"associate name"+user+"\n"+"gadget:"+gadgets+"\n"+"serial no:"+s_num+"\n"+"manufacturer:"+m_Name;

 





EditPage ep = new EditPage();

List<BasicDBObject> viewList = ep .recordRetrieve_2(edit_ID_E,visitorno);



               

rd = request.getRequestDispatcher("select_Visitor_1.jsp");

request.setAttribute("select1_E",viewList);

rd.forward(request, response);













}



if (module.equals("v_editing_E1")){



HttpSession hs = request.getSession();


String visitorno = "visitor_1";

System.out.println("\n the value of visitor"+visitorno);

String RID_E = (String) hs.getAttribute("rid_E");

String a_ID = (String) hs.getAttribute("f_key");

String user = (String) hs.getAttribute("user");

String edit_ID_E = (String) hs.getAttribute("edit_ID_E");



String V_Name = request.getParameter("v_Name");

String V_CompanyName = request.getParameter("comp");

String V_Email_ID = request.getParameter("email");

String V_Mobile_Number = request.getParameter("mob");

String V_Country = request.getParameter("country");

String V_City = request.getParameter("city");

String V_Address = request.getParameter("adrs");

String V_id_proof = request.getParameter("id");

String V_proof_no = request.getParameter("id_No");

String V_nationality = request.getParameter("Nationality");

String gadgets = request.getParameter("gadgets");

String s_num = request.getParameter("sno");

String m_Name = request.getParameter("manufacturer");

String status = request.getParameter("submit");



VisitorBean vb = new VisitorBean();



vb .setForeign(RID_E);

vb.setVisitor_Name(V_Name);

vb.setCompany_Name(V_CompanyName);

vb.setEmail_ID(V_Email_ID);

vb.setVisitor_Mob(V_Mobile_Number);

vb.setCountry(V_Country);

vb.setVisitor_City(V_City);

vb.setVisitor_Adr(V_Address);

vb.setVisitor_ID_Prf(V_id_proof);

vb.setVisitor_Prf_Num(V_proof_no);

vb.setVisitor_Nationality(V_nationality);

vb.setVisitor_Num(visitorno);

vb.setGadgets(gadgets);

vb.setS_Num(s_num);

vb.setM_Name(m_Name);

vb.setStatus(status);

EditRequest er = new EditRequest();

er.visitorAdd_E(vb,RID_E);



System.out.println("\n the visitor details got added");



String qrCodeData_E = "\n visitor_Name:"+V_Name+"\n visitor_Company:"+V_CompanyName+"\n visitor_ID:"

                                +V_id_proof+"\n visitor_ID_Num:"+V_proof_no+"\n"+"associate ID:"+

a_ID+"\n"+"associate name"+user+"\n"+"gadget:"+gadgets+"\n"+"serial no:"+s_num+"\n"+"manufacturer:"+m_Name;

 





EditPage ep = new EditPage();

List<BasicDBObject> viewList = ep .recordRetrieve_1(edit_ID_E);



               

rd = request.getRequestDispatcher("select_Visitor.jsp");

request.setAttribute("select_E",viewList);

rd.forward(request, response);
}

			}
public void destroy(ServletConfig sc){
	System.out.println("Servlet object destroyed");
}

	public static void main(String arg, String recipient) throws WriterException, IOException,NotFoundException {

		
String charset = "UTF-8"; 
Map<EncodeHintType, ErrorCorrectionLevel> hintMap = new HashMap<EncodeHintType, ErrorCorrectionLevel>();
hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);


	String from = "kiruthika.lingam95";
	String pass = "clunyschool";
	String to = recipient; // list of recipient email addresses
	String subject = "Java office mail example";
	String body = "Please use the below qr code";
	try {
		sendFromGMail(from, pass, to, subject, body,arg );
	} catch (WriterException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
public static  void sendFromGMail(String from, String pass, String to, String subject, String body,String data) throws IOException, WriterException {

String qrCodeData = data;
File image =new File("QRcode.jpg"); 
String charset = "UTF-8"; // or "ISO-8859-1"
Map<EncodeHintType, ErrorCorrectionLevel> hintMap = new HashMap<EncodeHintType, ErrorCorrectionLevel>();
hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);

BufferedImage src = createQRCode(qrCodeData, charset, hintMap, 200, 200);
ImageIO.write(src,"jpg",image);

System.out.println("conversion of buffered image to jpg done");
 
Properties props = System.getProperties();
String host = "smtp.gmail.com";

props.put("mail.smtp.starttls.enable", "true");
props.put("mail.smtp.host", host);
props.put("mail.smtp.user", from);
props.put("mail.smtp.password", pass);
props.put("mail.smtp.port", "587");
props.put("mail.smtp.auth", "true");



Session session = Session.getDefaultInstance(props, null);
MimeMessage message = new MimeMessage(session);



//multipart.addBodyPart();
try {

	MimeMultipart multipart = new MimeMultipart();
    message.setFrom(new InternetAddress(from));
    InternetAddress[] toAddress = new InternetAddress[1];
    message.setSubject(subject);
   
    // To get the array of addresses
    for( int i = 0; i < 1; i++ ) {
    	System.out.println("To address for block" + i + "\n");
        toAddress[i] = new InternetAddress(to);
        message.addRecipient(Message.RecipientType.TO, toAddress[i]);
    }


    BodyPart messageBodyPart = new MimeBodyPart();
    BodyPart messageBodyPart1 = new MimeBodyPart();    
    DataSource source = new FileDataSource(image.getName());
    messageBodyPart.setDataHandler(new DataHandler(source));
    messageBodyPart.setFileName(image.getName());
    messageBodyPart1.setContent(body,"text/html");
    
    multipart.addBodyPart(messageBodyPart);
    multipart.addBodyPart(messageBodyPart1);
    message.setContent(multipart);
    
 //   message.setText(body, "UTF-8", "html");


    Transport transport = session.getTransport("smtp");


    transport.connect(host, from, pass);
    transport.sendMessage(message, message.getAllRecipients());
    transport.close();
    System.out.println("Email Sent successfully");

}
catch (AddressException ae) {
    ae.printStackTrace();
}
catch (MessagingException me) {
    me.printStackTrace();
  }
 }


public static BufferedImage createQRCode(String qrCodeData, String charset, Map hintMap, int qrCodeheight, int qrCodewidth)
throws WriterException, IOException {
BitMatrix matrix = new MultiFormatWriter().encode(
new String(qrCodeData.getBytes(charset), charset),
BarcodeFormat.QR_CODE, qrCodewidth, qrCodeheight, hintMap);
BufferedImage img = MatrixToImageWriter.toBufferedImage(matrix);
System.out.println("QR code encoded");
return img;
}

public static String readQRCode(String filePath, String charset, Map hintMap)
throws FileNotFoundException, IOException, NotFoundException {
BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(
new BufferedImageLuminanceSource(
        ImageIO.read(new     FileInputStream(filePath)))));
Result qrCodeResult = new MultiFormatReader().decode(binaryBitmap,
hintMap);
return qrCodeResult.getText();
}

private String extractFileName(Part part) 
{
  String contentDisp = part.getHeader("content-disposition");
  String[] items = contentDisp.split(";");
  for (String s : items) {
  if (s.trim().startsWith("filename")) {
  return s.substring(s.indexOf("=") + 2, s.length()-1);
 }
}
  return "";
 }
public static String imageToBase64String(File imageFile)throws Exception{
	 
    String image=null;
    BufferedImage buffImage = ImageIO.read(imageFile);
    System.out.println("imageToBase64String block");
 if (buffImage != null) {
    java.io.ByteArrayOutputStream os = new 
                java.io.ByteArrayOutputStream();
    ImageIO.write(buffImage, "jpg", os);
    byte[] data = os.toByteArray();
//    image = MyBase64.encode(data);

//write to file the encoded character
os.close();
image = javax.xml.bind.DatatypeConverter.printBase64Binary(data);
      }//if
    return image;
   }
}

