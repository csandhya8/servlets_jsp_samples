package com.technicalkeeda;

import javax.servlet.annotation.WebServlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.Mongo;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSInputFile;

@WebServlet("/FileUploadServlet")
public class FileUploadServlet extends HttpServlet
{
	String name =null;
	String value =null;
   
    protected void processRequest( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException
    {
       
    	
    	// 8888888888888888888888888888888888
    	
    	boolean isMultipart = ServletFileUpload.isMultipartContent(request);
    	  /*String UPLOAD_DIRECTORY = request.getServletContext().getRealPath("/")+"imgs";
    	  System.out.println("UPLOAD_DIRECTORY= "+UPLOAD_DIRECTORY);
    	  */
    	  ServletContext servletContext = this.getServletConfig().getServletContext();
    	  
    	  File repository = (File) servletContext.getAttribute("javax.servlet.context.tempdir");
    	    	DiskFileItemFactory factory = new DiskFileItemFactory(1000 , repository);
    	    	 System.out.println(" File repository "+repository);
    	
    	    //process only if its multipart content
    	    if(isMultipart){
      	        try {
    	            @SuppressWarnings("unchecked")
					List<FileItem> multiparts = new ServletFileUpload(factory).parseRequest(request);

    	            FileItem item;
    	            int i=1;
    	            
    	            Iterator<FileItem> iter = multiparts.iterator();
    	            boolean imageFlag = false;
    	            while (iter.hasNext()) {
    	            	System.out.println("count ==== "+ i++);
    	            	byte[] imgBytes=null;
    	            	int length;
    	                item = iter.next();
                if (item.isFormField()) {
    	                	if(item.getFieldName().equals("nom"))
    	                	name = item.getString();
    	                	if(item.getFieldName().equals("date"))
    	                		value = item.getString();
    	                    System.out.println("inside while-if: "+name+" ---- "+value);
    	                    imageFlag=true;
    	                }  
                System.out.println("imageFlag1= "+imageFlag);
    	                 imageFlag = false;
    	                 System.out.println("imageFlag2= "+imageFlag);
    	                if (!(item.isFormField()))
    	                {
    	                  //  processUploadedFile(item);
    	                	
    	                	    String fieldName = item.getFieldName();
    	    	                String fileName = item.getName();
    	    	                imgBytes = item.get();
    	    	                System.out.println(" in else end---"+imgBytes);
    	    	                length= item.get().length;
    	    	                
    	    	                System.out.println(" in else end---"+length);
    	    	                imageFlag = true;
    	                }
    	                
    	                if(imageFlag==true){
    	                try{
    	               System.out.println("before mongo connection *****");
                        Mongo mongo = new Mongo( "127.0.0.1", 27017 );
                        String dbName = "local";
                        DB db = mongo.getDB( dbName );
                        System.out.println("before fs grid *****");
                        
                		DBCollection collection = db.getCollection("raise");
                		
                		BasicDBObject document = new BasicDBObject();
                		

                		
                        
                        //Create GridFS object
                        GridFS fs = new GridFS( db );
                        System.out.println("before createfile *****---"+imgBytes);
                        //Save image into database
                        GridFSInputFile in = fs.createFile( imgBytes );
                        
                        document.append("image",in);
                        document.append("username", name);
                        document.append("lastname", value);
                        collection.insert(document);
                        System.out.println("before save *****");
                       
                        System.out.println("after save *****");
                        System.out.println("File saved in mongo");
                        imageFlag = false;
    	                }catch(Exception e){
    	                	System.out.println("####################################");
    	                	e.printStackTrace();}
    	                
    	            }
    	            }
    	            
    	          /*  if (!item.isFormField()) {
    	                String fieldName = item.getFieldName();
    	                String fileName = item.getName();
    	                String contentType = item.getContentType();
    	                boolean isInMemory = item.isInMemory();
    	                long sizeInBytes = item.getSize();
    	            }*/
    	            
    	           //File uploaded successfully
    	           request.setAttribute("message", "File Uploaded Successfully");
    	           
    	           //log.debug("File updated successfully");
    	        } catch (Exception ex) {
    	           request.setAttribute("message", "File Upload Failed due to " + ex);
    	           request.getRequestDispatcher("/ok.jsp").forward(request, response);
    	           //log.debug("File upload failed: "+ex);
    	        }          

    	    }else{
    	        request.setAttribute("message",
    	                             "Sorry this Servlet only handles file upload request");
    	       
    	       // log.debug("file upload only !");
    	    }

    	    request.getRequestDispatcher("/ok.jsp").forward(request, response);

    	}
    	
    	
    public static byte[] LoadImage(String filePath) throws Exception {
        File file = new File(filePath);
        int size = (int)file.length();
        byte[] buffer = new byte[size];
        FileInputStream in = new FileInputStream(file);
        in.read(buffer);
        in.close();
        return buffer;
    }
    
   

    @Override
    protected void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException
    {
        processRequest( request, response );
    }
}