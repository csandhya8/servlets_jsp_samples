package com.technicalkeeda;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSInputFile;

public class FileUploadExample extends HttpServlet {
	
	
	
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
             throws ServletException, IOException {
	  String fileName= null;
         boolean isMultipart = ServletFileUpload.isMultipartContent(request);
  
         if (isMultipart) {
          // Create a factory for disk-based file items
          FileItemFactory factory = new DiskFileItemFactory();

          // Create a new file upload handler
          ServletFileUpload upload = new ServletFileUpload(factory);
  
             try {
              // Parse the request
              List /* FileItem */ items = upload.parseRequest(request);
                 Iterator iterator = items.iterator();
                 while (iterator.hasNext()) {
                     FileItem item = (FileItem) iterator.next();
                     if (!item.isFormField()) {
                      fileName = item.getName();  
                         String root = getServletContext().getRealPath("/");
                         File path = new File(root + "/uploads");
                         if (!path.exists()) {
                             boolean status = path.mkdirs();
                         }
  
                         File uploadedFile = new File(path + "/" + fileName);
                         System.out.println(uploadedFile.getAbsolutePath());
                         item.write(uploadedFile);
                         
                     }
                 }
                 
                 
                 
                 
                 
                 /*MongoClient mongoClient = new MongoClient("localhost"); // connect to mongodb
                 DB db = mongoClient.getDB("dynamsoft");                 // get database
      
                 GridFS fs = new GridFS(db, "twain");                    // GridFS for storing images
      
                 GridFSInputFile file = fs.createFile(fileName);
                 file.setContentType("image");
                 file.save();
                 System.out.println(file.toString());
                 mongoClient.close();  */
                 
                 
                 
             } catch (FileUploadException e) {
                 e.printStackTrace();
             } catch (Exception e) {
                 e.printStackTrace();
             }
         }
     }

}