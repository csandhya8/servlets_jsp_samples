package com.technicalkeeda;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
* Servlet implementation class AddProjectTaskDAO
*/
/*@WebServlet("/AddProjectTaskDAO")*/
public class AddProjectTaskDAO extends HttpServlet {
private static final long serialVersionUID = 1L;

/**
 * @see HttpServlet#HttpServlet()
 */
public AddProjectTaskDAO() {
    super();
    // TODO Auto-generated constructor stub
}

/**
 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
 */
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub

    response.setContentType("text/html");  
    PrintWriter pw = response.getWriter(); 

    Connection conn=null;
    String url="jdbc:mysql://localhost:3306/";
    String dbName="projectmanagement";
    String driver="com.mysql.jdbc.Driver";
    String dbUsername="root";
    String dbPassword="root";

    try{  

          String Projid=" ";
          String Projuname=" ";
          String Projdesc_emp=" ";
          String Projestd_time_alloc=" ";
          String Projtask_emp_comment=" ";
          String Pid[] = request.getParameterValues("pid");  
          String Uname[] = request.getParameterValues("uname");  
          String Pdesc_emp[] = request.getParameterValues("pdesc_emp"); 
          String Pestd_time_alloc[] =  request.getParameterValues("pestd_time_alloc");
          String Projtask_emp_cmnt[] = request.getParameterValues("ptask_emp_cmnt");  
          //String Utype = request.getParameter("utype");

          for(int i=0; i<100; i++){
              Projid=Pid[i]+" "+ 1;
              Projuname=Uname[i]+" "+ 1;
              Projdesc_emp=Pdesc_emp[i]+" "+ 1;
              Projestd_time_alloc=Pestd_time_alloc[i]+" "+ 1;
              Projtask_emp_comment=Projtask_emp_cmnt[i]+" "+ 1;
              }

          request.setAttribute("msg","Success!!!");  
          
          RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/MyPage.jsp!!"); 
          dispatcher.forward(request,response);
          /*Class.forName(driver);  
          conn = DriverManager.getConnection(url+dbName,dbUsername, dbPassword);
          Statement st=conn.createStatement();


          int i = st.executeUpdate("insert into projtaskallocate (pid,uname,ptdesc_emp,ptestd_time_alloc,ptask_emp_cmnt) values ('" +Projid+ "','" +Projuname+"','" +Projdesc_emp+ "','" +Projestd_time_alloc+ "','" +Projtask_emp_comment+ "')");

          String msg=" ";
          if(i!=0){  
          UserPMDAO dd = new UserPMDAO();
          request.setAttribute("ual", dd.getUsers());
          ProjectDAO pp = new ProjectDAO();
          request.setAttribute("pal", pp.getProjects());  
          String nextJSP = "/projmgrsuccessful.jsp"; 
          RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP); 
          dispatcher.forward(request,response);



          }  
          else
          {  
              msg="Failed to Add Project";
              pw.print("<font size='6' color=blue>" + msg + "</font>");
          }  
          pw.close();
          //pst.close();
          st.close();
          conn.close();*/
        }  
        catch (Exception e)
        {  
        e.printStackTrace(); 
        }  

}

/**
 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
 */
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub



}

}